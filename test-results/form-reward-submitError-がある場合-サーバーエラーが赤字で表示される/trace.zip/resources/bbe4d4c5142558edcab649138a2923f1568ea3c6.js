(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/organisms/RewardForm/schema.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rewardSchema",
    ()=>rewardSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const rewardSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].preprocess((v)=>v === undefined || v === null ? "" : v, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().min(1, "ご褒美を入力してください")),
    // ★ TodoForm と同じ書き方に統一（required_error を使わない）
    star: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.number().int("整数を入力してください").min(1, "1以上の数を入力してください"),
    image: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
        src: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
        file: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].instanceof(File).optional()
    }).optional()
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/atoms/Input/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
;
;
function Input({ hasError, hasBorder, small, height, style, className, ...rest }) {
    const borderColor = hasError ? "var(--danger)" : "transparent";
    const borderRadius = hasBorder ? "20px" : "5px";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        ...rest,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("inline-block box-border outline-none bg-[rgba(244,240,240,0.65)]", "placeholder-[rgba(225,136,131,0.9)]", small ? "w-[72px] text-center" : "w-full", className),
        style: {
            color: "#6B3734",
            border: `1px solid ${borderColor}`,
            borderRadius: borderRadius,
            padding: "16px 14px",
            fontSize: "var(--smallMedium)",
            lineHeight: "20px",
            height: height,
            ...style
        }
    }, void 0, false, {
        fileName: "[project]/src/components/atoms/Input/index.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
}
_c = Input;
var _c;
__turbopack_context__.k.register(_c, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/Dropzone/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Dropzone
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/index.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isDragEvt = (value)=>{
    return !!value.dataTransfer;
};
const isInput = (value)=>{
    return value !== null;
};
const getFilesFromEvent = (e)=>{
    if (isDragEvt(e)) {
        return Array.from(e.dataTransfer.files);
    } else if (isInput(e.target) && e.target.files) {
        return Array.from(e.target.files);
    }
    return [];
};
function Dropzone({ value = [], name, acceptedFileTypes = [
    "image/png",
    "image/jpeg",
    "image/jpg",
    "image/gif"
], width = "100px", height = "100px", hasError, radius, onDrop, onChange, register }) {
    _s();
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isFocused, setIsFocused] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const hasImage = value.length > 0;
    const handleChange = (e)=>{
        setIsFocused(false);
        const dropped = getFilesFromEvent(e);
        if (dropped.length > 0) {
            const newFile = dropped[dropped.length - 1];
            return onDrop?.([
                newFile
            ]);
        }
    };
    const handleDrop = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setIsFocused(false);
        const dropped = getFilesFromEvent(e).filter((f)=>acceptedFileTypes.includes(f.type));
        if (dropped.length === 0) {
            return window.alert(`次のファイルフォーマットは指定できません: ${acceptedFileTypes.join(", ")}`);
        }
        const newFiles = dropped[dropped.length - 1];
        onDrop?.([
            newFiles
        ]);
        onChange?.([
            newFiles
        ]);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Dropzone.useEffect": ()=>{
            if (inputRef.current && value.length === 0) {
                inputRef.current.value = "";
            }
        }
    }["Dropzone.useEffect"], [
        value
    ]);
    const borderColor = hasError ? "border-[#ed1c24]" : isFocused ? "border-[#E18883]" : "border-transparent";
    const radiusClass = radius ? "rounded-full" : "rounded-[5px]";
    const bgStyle = !hasImage ? {
        backgroundImage: "url(/images/bear02.webp)",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "center",
        backgroundSize: "contain",
        backgroundColor: "rgba(246,238,237,0.65)",
        backgroundBlendMode: "lighten"
    } : undefined;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        onDrop: handleDrop,
        onDragOver: (e)=>e.preventDefault(),
        onDragLeave: ()=>setIsFocused(false),
        onDragEnter: ()=>setIsFocused(true),
        onClick: ()=>!hasImage && inputRef.current?.click(),
        "data-testid": "dropzone",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("relative cursor-pointer border border-dashed transition-all duration-150 flex items-center justify-center", borderColor, radiusClass),
        style: {
            width,
            height,
            ...bgStyle
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "file",
                accept: "image/*",
                ...register(name),
                ref: inputRef,
                onChange: handleChange,
                className: "hidden"
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Dropzone/index.tsx",
                lineNumber: 131,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center justify-center",
                style: {
                    width,
                    height
                },
                children: !hasImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileUploadIcon"], {
                    size: 32,
                    color: "var(--borderDash)",
                    ariaLabel: "ファイルアップロードボタン"
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/Dropzone/index.tsx",
                    lineNumber: 146,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Dropzone/index.tsx",
                lineNumber: 141,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/Dropzone/index.tsx",
        lineNumber: 117,
        columnNumber: 5
    }, this);
}
_s(Dropzone, "6EGGX1jjH+Ll0nEJ2OXOKJuoU3M=");
_c = Dropzone;
var _c;
__turbopack_context__.k.register(_c, "Dropzone");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/ImagePreview/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/index.tsx [app-client] (ecmascript)");
;
;
;
function CloseBox({ children, ...rest }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ...rest,
        className: "flex items-center justify-center absolute top-0 right-[-20px] w-[30px] h-[30px] rounded-full bg-[rgba(243, 228, 227, 0.66)] cursor-pointer",
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/molecules/ImagePreview/index.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = CloseBox;
/**
 * イメージプレビュー
 */ const ImagePreview = ({ src, height = '100px', width = '100px', onRemove })=>{
    // 閉じるボタンを押したらonRemoveを呼ぶ
    const handleCloseClick = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        onRemove && src && onRemove(src);
        return false;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                style: {
                    height,
                    width
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    quality: "85",
                    src: src,
                    alt: "イメージ",
                    sizes: "25.6vw",
                    fill: true,
                    style: {
                        objectFit: "contain",
                        objectPosition: '50% 50%'
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/ImagePreview/index.tsx",
                    lineNumber: 49,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/ImagePreview/index.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CloseBox, {
                onClick: handleCloseClick,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CloseIcon"], {
                    size: 24,
                    color: "var(--white)",
                    ariaLabel: "閉じる"
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/ImagePreview/index.tsx",
                    lineNumber: 61,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/ImagePreview/index.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
_c1 = ImagePreview;
const __TURBOPACK__default__export__ = ImagePreview;
var _c, _c1;
__turbopack_context__.k.register(_c, "CloseBox");
__turbopack_context__.k.register(_c1, "ImagePreview");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/molecules/InputImages/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// InputImage.tsx（1枚専用）
__turbopack_context__.s([
    "default",
    ()=>InputImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Dropzone$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/Dropzone/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$ImagePreview$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/ImagePreview/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function InputImage({ name, image, hasError, width = "100px", height = "100px", radius = false, register, onChange }) {
    _s();
    const [localImage, setLocalImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(image);
    // 外から渡される image が更新されたら反映
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InputImage.useEffect": ()=>{
            setLocalImage(image);
        }
    }["InputImage.useEffect"], [
        image
    ]);
    // Dropzone のファイル受取
    const handleDrop = (files)=>{
        if (files.length === 0) return;
        const file = files[0];
        const img = {
            file,
            src: URL.createObjectURL(file)
        };
        setLocalImage(img);
        onChange?.(img);
    };
    const handleRemove = ()=>{
        setLocalImage(undefined);
        onChange?.(undefined);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        style: {
            width,
            height
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Dropzone$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                name: `${name}.file`,
                value: localImage?.file ? [
                    localImage.file
                ] : [],
                onDrop: handleDrop,
                hasError: hasError,
                width: width,
                height: height,
                radius: radius,
                register: register
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/InputImages/index.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            localImage?.src && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 flex items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$ImagePreview$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: localImage.src,
                    width: width,
                    height: height,
                    onRemove: handleRemove
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/InputImages/index.tsx",
                    lineNumber: 79,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/InputImages/index.tsx",
                lineNumber: 78,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/InputImages/index.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}
_s(InputImage, "qr4mUkUJSWy9RXQaICDWRfL6aSQ=");
_c = InputImage;
var _c;
__turbopack_context__.k.register(_c, "InputImage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/RewardForm/data:3b63a7 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"60cc37ece960ee1f563d1b003e0dfa91124f5b4caf":"createReward"},"src/components/organisms/RewardForm/action.ts",""] */ __turbopack_context__.s([
    "createReward",
    ()=>createReward
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var createReward = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60cc37ece960ee1f563d1b003e0dfa91124f5b4caf", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createReward"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJld2FyZEZvcm0vYWN0aW9uLnRzXG5cInVzZSBzZXJ2ZXJcIjtcblxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSBcIkAvbGlicy9zdXBhYmFzZS9zZXJ2ZXJcIjtcbmltcG9ydCB7IHByaXNtYSB9IGZyb20gXCJzcmMvbGlicy9wcmlzbWFcIjtcbmltcG9ydCB7IFpvZEVycm9yIH0gZnJvbSBcInpvZFwiO1xuaW1wb3J0IHsgcmV2YWxpZGF0ZVRhZyB9IGZyb20gXCJuZXh0L2NhY2hlXCI7XG5pbXBvcnQge1xuICB2YWxpZGF0ZUZvcm1EYXRhLFxuICB0cmFuc2Zvcm1GaWVsZEVycm9ycyxcbn0gZnJvbSBcInNyYy91dGlscy92YWxpZGF0ZVwiO1xuaW1wb3J0IHtcbiAgaGFuZGxlRXJyb3IsXG4gIGVycm9ycyxcbiAgdHlwZSBGb3JtU3RhdGUsXG4gIGhhbmRsZVN1Y2Nlc3MsXG59IGZyb20gXCJzcmMvdXRpbHMvc3RhdGVcIjtcbmltcG9ydCB7IHJld2FyZFNjaGVtYSB9IGZyb20gXCIuL3NjaGVtYVwiO1xuaW1wb3J0IHR5cGUgeyBSZXdhcmRJbnB1dCB9IGZyb20gXCIuL3NjaGVtYVwiO1xuaW1wb3J0IHsgdXBsb2FkSW1hZ2UgfSBmcm9tIFwic3JjL2xpYnMvc3VwYWJhc2UvdXBsb2FkSW1hZ2VcIjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVJld2FyZChcbiAgcHJldlN0YXRlOiBGb3JtU3RhdGU8UmV3YXJkSW5wdXQ+LFxuICBmb3JtRGF0YTogRm9ybURhdGEsXG4pOiBQcm9taXNlPEZvcm1TdGF0ZTxSZXdhcmRJbnB1dD4+IHtcblxuICAgLy9lMmUgcGxheXdyaWdodOODhuOCueODiOeUqFxuICAgY29uc3QgaXNFMkUgPSBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19FMkVfVEVTVCA9PT0gXCJ0cnVlXCI7XG4gICBjb25zdCBmb3JjZUVycm9yID0gZm9ybURhdGEuZ2V0KFwiX19mb3JjZVNlcnZlckVycm9yXCIpID09PSBcIjFcIjtcblxuICAgaWYgKGlzRTJFICYmIGZvcmNlRXJyb3IpIHtcbiAgICAgcmV0dXJuIGhhbmRsZUVycm9yKHByZXZTdGF0ZSwge1xuICAgICAgIC4uLmVycm9yc1s1MDBdLFxuICAgICAgIG1lc3NhZ2U6IFwi44K144O844OQ44O844Ko44Op44O844GM55m655Sf44GX44G+44GX44GfXCIsXG4gICAgIH0pO1xuICAgfVxuXG4gICBpZiAoaXNFMkUpIHtcbiAgICAgLy8g44OV44Kp44O844Og44Gu5YCk44Gg44GR6Lu944GP44OQ44Oq44OH44O844K344On44Oz44GX44Gm5Y2z5oiQ5YqfXG4gICAgIHRyeSB7XG4gICAgICAgdmFsaWRhdGVGb3JtRGF0YShmb3JtRGF0YSwgcmV3YXJkU2NoZW1hKTtcbiAgICAgICByZXR1cm4gaGFuZGxlU3VjY2VzcyhwcmV2U3RhdGUpO1xuICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICBpZiAoZXJyIGluc3RhbmNlb2YgWm9kRXJyb3IpIHtcbiAgICAgICAgIHJldHVybiBoYW5kbGVFcnJvcihwcmV2U3RhdGUsIHtcbiAgICAgICAgICAgLi4uZXJyb3JzWzQwMF0sXG4gICAgICAgICAgIGZpZWxkRXJyb3JzOiB0cmFuc2Zvcm1GaWVsZEVycm9ycyhlcnIpLFxuICAgICAgICAgfSk7XG4gICAgICAgfVxuICAgICAgIHJldHVybiBoYW5kbGVFcnJvcihwcmV2U3RhdGUsIGVycm9yc1s1MDBdKTtcbiAgICAgfVxuICAgfVxuXG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XG4gIGNvbnN0IHsgZGF0YTogeyB1c2VyIH0gfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xuICBpZiAoIXVzZXIpIHJldHVybiBoYW5kbGVFcnJvcihwcmV2U3RhdGUsIGVycm9yc1s0MDFdKTtcblxuICBjb25zdCB1c2VySWQgPSB1c2VyLmlkOyAvLyBhdXRoLnVzZXJzLmlkID09PSBQcm9maWxlLnVzZXJJZFxuXG4gIHRyeSB7XG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyDikaAgWm9kIOODkOODquODh+ODvOOCt+ODp+ODs1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgY29uc3QgcGF5bG9hZCA9IHZhbGlkYXRlRm9ybURhdGEoZm9ybURhdGEsIHJld2FyZFNjaGVtYSk7XG4gICAgY29uc3QgeyB0aXRsZSwgc3RhciwgaW1hZ2UgfSA9IHBheWxvYWQ7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIOKRoSBGb3JtRGF0YSDjgYvjgokgRmlsZSDmir3lh7pcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIGxldCBmb3JtRmlsZTogRmlsZSB8IG51bGwgPSBudWxsO1xuXG4gICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgZm9ybURhdGEuZW50cmllcygpKSB7XG4gICAgICBpZiAoa2V5ID09PSBcImltYWdlLmZpbGVcIiAmJiB2YWx1ZSBpbnN0YW5jZW9mIEZpbGUgJiYgdmFsdWUuc2l6ZSA+IDApIHtcbiAgICAgICAgZm9ybUZpbGUgPSB2YWx1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgTUFYX1NJWkUgPSA1ICogMTAyNCAqIDEwMjQ7XG4gICAgY29uc3QgQUxMT1dFRF9UWVBFUyA9IFtcImltYWdlL2pwZWdcIiwgXCJpbWFnZS9wbmdcIiwgXCJpbWFnZS93ZWJwXCJdO1xuXG4gICAgaWYgKGZvcm1GaWxlICYmIGZvcm1GaWxlLnNpemUgPiAwKSB7XG4gICAgICBpZiAoZm9ybUZpbGUuc2l6ZSA+IE1BWF9TSVpFKSB7XG4gICAgICAgIHJldHVybiBoYW5kbGVFcnJvcihwcmV2U3RhdGUsIHtcbiAgICAgICAgICAuLi5lcnJvcnNbNDAwXSxcbiAgICAgICAgICBtZXNzYWdlOiBcIueUu+WDj+OCteOCpOOCuuOBrzVNQuS7peWGheOBq+OBl+OBpuOBj+OBoOOBleOBhFwiLFxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFBTExPV0VEX1RZUEVTLmluY2x1ZGVzKGZvcm1GaWxlLnR5cGUpKSB7XG4gICAgICAgIHJldHVybiBoYW5kbGVFcnJvcihwcmV2U3RhdGUsIHtcbiAgICAgICAgICAuLi5lcnJvcnNbNDAwXSxcbiAgICAgICAgICBtZXNzYWdlOiBcImpwZyAvIHBuZyAvIHdlYnAg44Gu44G/44Ki44OD44OX44Ot44O844OJ44Gn44GN44G+44GZXCIsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8g4pGiIOeUu+WDj+OCouODg+ODl+ODreODvOODiSAvIOaXouWtmOWIqeeUqFxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgbGV0IGltYWdlUGF0aDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbiAgICBpZiAoZm9ybUZpbGUpIHtcbiAgICAgIGltYWdlUGF0aCA9IGF3YWl0IHVwbG9hZEltYWdlKGZvcm1GaWxlLCB1c2VySWQsIFwicmV3YXJkXCIpO1xuICAgIH0gZWxzZSBpZiAoaW1hZ2U/LnNyYykge1xuICAgICAgaW1hZ2VQYXRoID0gaW1hZ2Uuc3JjO1xuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8g4pGjIERCIOS/neWtmO+8iFByb2ZpbGUg44Gr57SQ44Gl44GR44KL77yJXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBhd2FpdCBwcmlzbWEucmV3YXJkLmNyZWF0ZSh7XG4gICAgICBkYXRhOiB7XG4gICAgICAgIHRpdGxlLFxuICAgICAgICBzdGFyLFxuICAgICAgICBpbWFnZTogaW1hZ2VQYXRoLFxuICAgICAgICB1c2VySWQsIC8vIOKGkCDlv4XpoIhcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICByZXZhbGlkYXRlVGFnKFwicmV3YXJkc1wiLFwibWF4XCIpO1xuICAgIHJldHVybiBoYW5kbGVTdWNjZXNzKHByZXZTdGF0ZSk7XG5cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIFpvZEVycm9yKSB7XG4gICAgICByZXR1cm4gaGFuZGxlRXJyb3IocHJldlN0YXRlLCB7XG4gICAgICAgIC4uLmVycm9yc1s0MDBdLFxuICAgICAgICBmaWVsZEVycm9yczogdHJhbnNmb3JtRmllbGRFcnJvcnMoZXJyKSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICByZXR1cm4gaGFuZGxlRXJyb3IocHJldlN0YXRlLCBlcnJvcnNbNTAwXSk7XG4gIH1cbn0iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Im1UQXFCc0IifQ==
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/validate.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "transformFieldErrors",
    ()=>transformFieldErrors,
    "validateFormData",
    ()=>validateFormData
]);
function validateFormData(formData, schema) {
    const obj = {};
    for (const [key, value] of formData.entries()){
        if (value === "") continue; // 🔥 未入力はキーごと消す
        if (value instanceof File && value.size === 0) continue;
        obj[key] = value;
    }
    return schema.parse(obj);
}
function transformFieldErrors(err) {
    return Object.fromEntries(err.issues.map(({ path, message })=>[
            String(path[0]),
            {
                message
            }
        ]));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/organisms/RewardForm/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
//import { zodResolver } from '@hookform/resolvers/zod';
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$RewardForm$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/organisms/RewardForm/schema.ts [app-client] (ecmascript)");
//import { Transition } from '@headlessui/react'
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
//import { useTimeoutFn } from 'react-use'
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Input/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputImages$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/molecules/InputImages/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/IconButton/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Spinner$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/atoms/Spinner/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$RewardForm$2f$data$3a$3b63a7__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/components/organisms/RewardForm/data:3b63a7 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$validate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/validate.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hot-toast/dist/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const initialFormState = (initialState)=>({
        updatedAt: Date.now().toString(),
        title: "",
        star: 0,
        image: {},
        error: null,
        status: "idle",
        ...initialState
    });
const RewardForm = ()=>{
    _s();
    const [state, formAction, isPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$RewardForm$2f$data$3a$3b63a7__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["createReward"], initialFormState());
    /* 成功後3秒でメッセージ非表示 
  useEffect(() => {
    if (state.status === "success") {
      setShowSuccess(true);
      document.querySelector("form")?.reset();
  
      const timer = setTimeout(() => {
        setShowSuccess(false); // ← UI 上で非表示に
      }, 3000);
  
      return () => clearTimeout(timer);
    }
  }, [state.status]);
  */ const [clientErrors, setClientErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(state.error?.fieldErrors);
    const errors = clientErrors || state.error?.fieldErrors;
    // 送信前に Client バリデーションを実施
    function handleSubmit(event) {
        try {
            const formData = new FormData(event.currentTarget);
            // バリデーションエラーが発生した場合 catch 句へ
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$validate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateFormData"])(formData, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$organisms$2f$RewardForm$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rewardSchema"]);
            // Client バリデーションエラーをクリア
            setClientErrors(undefined);
        } catch (err) {
            // ★: Form のサブミット（action 実行）を中止
            event.preventDefault();
            if (!(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ZodError"])) throw err;
            // Zod のバリデーションエラーをマッピング
            setClientErrors((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$validate$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transformFieldErrors"])(err));
        }
    }
    const { register, control, reset } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"])({
        defaultValues: state,
        mode: 'onChange'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RewardForm.useEffect": ()=>{
            if (state.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].success(`追加しました！`, {
                    iconTheme: {
                        primary: '#e8524a',
                        secondary: '#F3E4E3'
                    }
                });
                // フォームの値を初期化
                reset(initialFormState());
            }
        }
    }["RewardForm.useEffect"], [
        state.status,
        reset
    ]);
    /*
    const [isShowing, setIsShowing] = useState(false)
    const [, , resetIsShowing] = useTimeoutFn(() => setIsShowing(false), 2000)

    const onSubmit = (data: RewardInput) => {
      try {
        onRewardSave?.(data)
        // 成功時のみメッセージを表示
        setIsShowing(true)
        resetIsShowing()
        // フォームリセット
        reset()
      } catch (err) {
        console.error('Reward save failed:', err)
        // エラー時は何も表示しない
      }
    }
*/ // ボタンdisabled制御
    const isDisabled = isPending;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            action: formAction,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "hidden",
                    name: "__forceServerError",
                    value: ("TURBOPACK compile-time truthy", 1) ? '1' : "TURBOPACK unreachable"
                }, void 0, false, {
                    fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                    lineNumber: 120,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Controller"], {
                                            control: control,
                                            name: "image",
                                            rules: {
                                                required: false
                                            },
                                            render: ({ field })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputImages$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    image: field.value,
                                                    name: "image",
                                                    register: register,
                                                    onChange: field.onChange,
                                                    hasError: !!errors?.image
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                                    lineNumber: 129,
                                                    columnNumber: 15
                                                }, void 0)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                            lineNumber: 124,
                                            columnNumber: 13
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        errors?.image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            role: "alert",
                                            "data-testid": "reward-image",
                                            className: "text-(--danger) text-[13px] pl-1",
                                            children: errors.image.message
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                            lineNumber: 139,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                    lineNumber: 123,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            ...register('title'),
                                            name: "title",
                                            height: "28px",
                                            type: "text",
                                            placeholder: "テディベア",
                                            hasError: !!errors?.title,
                                            className: "text-center"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                            lineNumber: 145,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$IconButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StarIcon"], {
                                                    size: 32,
                                                    color: "var(--starLight)",
                                                    ariaLabel: "星"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                                    lineNumber: 155,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Input$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    ...register('star', {
                                                        valueAsNumber: true
                                                    }),
                                                    name: "star",
                                                    height: "32px",
                                                    type: "number",
                                                    placeholder: "100",
                                                    small: true,
                                                    hasError: !!errors?.star
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                                    lineNumber: 156,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[14px] text-(--text)",
                                                    children: "個と交換"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                                    lineNumber: 165,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                            lineNumber: 154,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                    lineNumber: 144,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                            lineNumber: 122,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        errors?.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "alert",
                            "data-testid": "reward-title",
                            className: "text-(--danger) text-[13px]",
                            children: errors.title.message
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                            lineNumber: 170,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        errors?.star && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "alert",
                            "data-testid": "reward-star",
                            className: "text-(--danger) text-[13px]",
                            children: errors.star.message
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                            lineNumber: 173,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "submit",
                            disabled: isDisabled,
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("border-b border-(--text) text-(--text) text-[16px] enabled:cursor-pointer enabled:hover:text-(--placeholder) enabled:hover:border-(--placeholder)", !!errors?.title || !!errors?.star || !!state.error ? "text-(--danger) border-b-0" : "text-(--border) border-(--border)", isDisabled && "opacity-50 cursor-not-allowed", isPending && "opacity-100 border-b-0"),
                            "data-testid": "add-reward",
                            "aria-label": "ご褒美作成",
                            children: isPending ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$atoms$2f$Spinner$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        size: 16,
                                        strokeWidth: 2
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                        lineNumber: 189,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "作成中..."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                        lineNumber: 190,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                                lineNumber: 188,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)) : "追加する"
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                            lineNumber: 175,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        state.error?.message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            role: "alert",
                            "data-testid": "rewardform-server-error",
                            className: "mt-1 text-center text-(--danger) text-[13px]",
                            children: state.error.message
                        }, void 0, false, {
                            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                            lineNumber: 197,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
                    lineNumber: 121,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/organisms/RewardForm/index.tsx",
            lineNumber: 119,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false);
};
_s(RewardForm, "UVkBu54WK3gV1uybQpa0e+YbD2A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"]
    ];
});
_c = RewardForm;
const __TURBOPACK__default__export__ = RewardForm;
var _c;
__turbopack_context__.k.register(_c, "RewardForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_aa11b7ec._.js.map