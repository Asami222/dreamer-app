(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_e0db07cc._.js",
  "static/chunks/src_aa11b7ec._.js"
],
    source: "dynamic"
});
