(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_organisms_Header_HeaderSkeleton_tsx_cfad2a9e._.js"
],
    source: "dynamic"
});
