(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@headlessui/react/dist/utils/env.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "env",
    ()=>s
]);
var i = Object.defineProperty;
var d = (t, e, n)=>e in t ? i(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : t[e] = n;
var r = (t, e, n)=>(d(t, typeof e != "symbol" ? e + "" : e, n), n);
class o {
    constructor(){
        r(this, "current", this.detect());
        r(this, "handoffState", "pending");
        r(this, "currentId", 0);
    }
    set(e) {
        this.current !== e && (this.handoffState = "pending", this.currentId = 0, this.current = e);
    }
    reset() {
        this.set(this.detect());
    }
    nextId() {
        return ++this.currentId;
    }
    get isServer() {
        return this.current === "server";
    }
    get isClient() {
        return this.current === "client";
    }
    detect() {
        return typeof window == "undefined" || typeof document == "undefined" ? "server" : "client";
    }
    handoff() {
        this.handoffState === "pending" && (this.handoffState = "complete");
    }
    get isHandoffComplete() {
        return this.handoffState === "complete";
    }
}
let s = new o;
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/owner.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getActiveElement",
    ()=>e,
    "getOwnerDocument",
    ()=>l,
    "getRootNode",
    ()=>r,
    "isActiveElement",
    ()=>d
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/env.js [app-client] (ecmascript)");
;
function l(n) {
    var u;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].isServer ? null : n == null ? document : (u = n == null ? void 0 : n.ownerDocument) != null ? u : document;
}
function r(n) {
    var u, o;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].isServer ? null : n == null ? document : (o = (u = n == null ? void 0 : n.getRootNode) == null ? void 0 : u.call(n)) != null ? o : document;
}
function e(n) {
    var u, o;
    return (o = (u = r(n)) == null ? void 0 : u.activeElement) != null ? o : null;
}
function d(n) {
    return e(n) === n;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/micro-task.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "microTask",
    ()=>t
]);
function t(e) {
    typeof queueMicrotask == "function" ? queueMicrotask(e) : Promise.resolve().then(e).catch((o)=>setTimeout(()=>{
            throw o;
        }));
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "disposables",
    ()=>o
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$micro$2d$task$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/micro-task.js [app-client] (ecmascript)");
;
function o() {
    let s = [], r = {
        addEventListener (e, t, n, i) {
            return e.addEventListener(t, n, i), r.add(()=>e.removeEventListener(t, n, i));
        },
        requestAnimationFrame (...e) {
            let t = requestAnimationFrame(...e);
            return r.add(()=>cancelAnimationFrame(t));
        },
        nextFrame (...e) {
            return r.requestAnimationFrame(()=>r.requestAnimationFrame(...e));
        },
        setTimeout (...e) {
            let t = setTimeout(...e);
            return r.add(()=>clearTimeout(t));
        },
        microTask (...e) {
            let t = {
                current: !0
            };
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$micro$2d$task$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["microTask"])(()=>{
                t.current && e[0]();
            }), r.add(()=>{
                t.current = !1;
            });
        },
        style (e, t, n) {
            let i = e.style.getPropertyValue(t);
            return Object.assign(e.style, {
                [t]: n
            }), this.add(()=>{
                Object.assign(e.style, {
                    [t]: i
                });
            });
        },
        group (e) {
            let t = o();
            return e(t), this.add(()=>t.dispose());
        },
        add (e) {
            return s.includes(e) || s.push(e), ()=>{
                let t = s.indexOf(e);
                if (t >= 0) for (let n of s.splice(t, 1))n();
            };
        },
        dispose () {
            for (let e of s.splice(0))e();
        }
    };
    return r;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-disposables.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDisposables",
    ()=>p
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
;
;
function p() {
    let [e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>()=>e.dispose(), [
        e
    ]), e;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useIsoMorphicEffect",
    ()=>n
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/env.js [app-client] (ecmascript)");
;
;
let n = (e, t)=>{
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].isServer ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(e, t) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])(e, t);
};
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-latest-value.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useLatestValue",
    ()=>s
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
;
;
function s(e) {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(e);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        r.current = e;
    }, [
        e
    ]), r;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useEvent",
    ()=>o
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-latest-value.js [app-client] (ecmascript)");
;
;
let o = function(t) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLatestValue"])(t);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "o.useCallback": (...r)=>e.current(...r)
    }["o.useCallback"], [
        e
    ]);
};
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-active-press.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useActivePress",
    ()=>w
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/owner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
;
;
;
;
function E(e) {
    let t = e.width / 2, n = e.height / 2;
    return {
        top: e.clientY - n,
        right: e.clientX + t,
        bottom: e.clientY + n,
        left: e.clientX - t
    };
}
function P(e, t) {
    return !(!e || !t || e.right < t.left || e.left > t.right || e.bottom < t.top || e.top > t.bottom);
}
function w({ disabled: e = !1 } = {}) {
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [n, l] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisposables"])(), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(()=>{
        t.current = null, l(!1), r.dispose();
    }), f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((s)=>{
        if (r.dispose(), t.current === null) {
            t.current = s.currentTarget, l(!0);
            {
                let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnerDocument"])(s.currentTarget);
                r.addEventListener(i, "pointerup", o, !1), r.addEventListener(i, "pointermove", (c)=>{
                    if (t.current) {
                        let p = E(c);
                        l(P(p, t.current.getBoundingClientRect()));
                    }
                }, !1), r.addEventListener(i, "pointercancel", o, !1);
            }
        }
    });
    return {
        pressed: n,
        pressProps: e ? {} : {
            onPointerDown: f,
            onPointerUp: o,
            onClick: o
        }
    };
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-element-size.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useElementSize",
    ()=>w
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
;
;
;
function h(i) {
    if (i === null) return {
        width: 0,
        height: 0
    };
    let { width: t, height: e } = i.getBoundingClientRect();
    return {
        width: t,
        height: e
    };
}
function w(i, t, e = !1) {
    let [r, f] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(()=>h(t));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        if (!t || !i) return;
        let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])();
        return n.requestAnimationFrame(function s() {
            n.requestAnimationFrame(s), f((u)=>{
                let o = h(t);
                return o.width === u.width && o.height === u.height ? u : o;
            });
        }), ()=>{
            n.dispose();
        };
    }, [
        t,
        i
    ]), e ? {
        width: `${r.width}px`,
        height: `${r.height}px`
    } : r;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/components/mouse.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MouseButton",
    ()=>g
]);
var g = ((f)=>(f[f.Left = 0] = "Left", f[f.Right = 2] = "Right", f))(g || {});
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hasInlineStyle",
    ()=>r,
    "isElement",
    ()=>t,
    "isHTMLElement",
    ()=>n,
    "isHTMLFieldSetElement",
    ()=>a,
    "isHTMLIframeElement",
    ()=>u,
    "isHTMLInputElement",
    ()=>l,
    "isHTMLLabelElement",
    ()=>m,
    "isHTMLLegendElement",
    ()=>E,
    "isHTMLTextAreaElement",
    ()=>s,
    "isHTMLorSVGElement",
    ()=>i,
    "isInteractiveElement",
    ()=>L,
    "isNode",
    ()=>o
]);
function o(e) {
    return typeof e != "object" || e === null ? !1 : "nodeType" in e;
}
function t(e) {
    return o(e) && "tagName" in e;
}
function n(e) {
    return t(e) && "accessKey" in e;
}
function i(e) {
    return t(e) && "tabIndex" in e;
}
function r(e) {
    return t(e) && "style" in e;
}
function u(e) {
    return n(e) && e.nodeName === "IFRAME";
}
function l(e) {
    return n(e) && e.nodeName === "INPUT";
}
function s(e) {
    return n(e) && e.nodeName === "TEXTAREA";
}
function m(e) {
    return n(e) && e.nodeName === "LABEL";
}
function a(e) {
    return n(e) && e.nodeName === "FIELDSET";
}
function E(e) {
    return n(e) && e.nodeName === "LEGEND";
}
function L(e) {
    return t(e) ? e.matches('a[href],audio[controls],button,details,embed,iframe,img[usemap],input:not([type="hidden"]),label,select,textarea,video[controls]') : !1;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/bugs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isDisabledReactIssue7711",
    ()=>s
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
;
function s(l) {
    let e = l.parentElement, t = null;
    for(; e && !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLFieldSetElement"](e);)__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLLegendElement"](e) && (t = e), e = e.parentElement;
    let i = (e == null ? void 0 : e.getAttribute("disabled")) === "";
    return i && r(t) ? !1 : i;
}
function r(l) {
    if (!l) return !1;
    let e = l.previousElementSibling;
    for(; e !== null;){
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLLegendElement"](e)) return !1;
        e = e.previousElementSibling;
    }
    return !0;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-handle-toggle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useHandleToggle",
    ()=>s
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$mouse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/mouse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$bugs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/bugs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
;
;
;
;
function s(t) {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((e)=>{
        r.current = e.pointerType, !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$bugs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDisabledReactIssue7711"])(e.currentTarget) && e.pointerType === "mouse" && e.button === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$mouse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MouseButton"].Left && (e.preventDefault(), t(e));
    }), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((e)=>{
        r.current !== "mouse" && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$bugs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDisabledReactIssue7711"])(e.currentTarget) || t(e));
    });
    return {
        onPointerDown: u,
        onClick: i
    };
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/default-map.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DefaultMap",
    ()=>a
]);
class a extends Map {
    constructor(t){
        super();
        this.factory = t;
    }
    get(t) {
        let e = super.get(t);
        return e === void 0 && (e = this.factory(t), this.set(t, e)), e;
    }
}
;
}),
"[project]/node_modules/@headlessui/react/dist/machine.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Machine",
    ()=>T,
    "batch",
    ()=>k,
    "shallowEqual",
    ()=>j
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$default$2d$map$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/default-map.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/env.js [app-client] (ecmascript)");
var h = Object.defineProperty;
var v = (t, e, r)=>e in t ? h(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : t[e] = r;
var S = (t, e, r)=>(v(t, typeof e != "symbol" ? e + "" : e, r), r), b = (t, e, r)=>{
    if (!e.has(t)) throw TypeError("Cannot " + r);
};
var i = (t, e, r)=>(b(t, e, "read from private field"), r ? r.call(t) : e.get(t)), c = (t, e, r)=>{
    if (e.has(t)) throw TypeError("Cannot add the same private member more than once");
    e instanceof WeakSet ? e.add(t) : e.set(t, r);
}, u = (t, e, r, s)=>(b(t, e, "write to private field"), s ? s.call(t, r) : e.set(t, r), r);
var n, a, o;
;
;
;
class T {
    constructor(e){
        c(this, n, {});
        c(this, a, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$default$2d$map$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultMap"](()=>new Set));
        c(this, o, new Set);
        S(this, "disposables", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])());
        u(this, n, e), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].isServer && this.disposables.microTask(()=>{
            this.dispose();
        });
    }
    dispose() {
        this.disposables.dispose();
    }
    get state() {
        return i(this, n);
    }
    subscribe(e, r) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].isServer) return ()=>{};
        let s = {
            selector: e,
            callback: r,
            current: e(i(this, n))
        };
        return i(this, o).add(s), this.disposables.add(()=>{
            i(this, o).delete(s);
        });
    }
    on(e, r) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].isServer ? ()=>{} : (i(this, a).get(e).add(r), this.disposables.add(()=>{
            i(this, a).get(e).delete(r);
        }));
    }
    send(e) {
        let r = this.reduce(i(this, n), e);
        if (r !== i(this, n)) {
            u(this, n, r);
            for (let s of i(this, o)){
                let l = s.selector(i(this, n));
                j(s.current, l) || (s.current = l, s.callback(l));
            }
            for (let s of i(this, a).get(e.type))s(i(this, n), e);
        }
    }
}
n = new WeakMap, a = new WeakMap, o = new WeakMap;
function j(t, e) {
    return Object.is(t, e) ? !0 : typeof t != "object" || t === null || typeof e != "object" || e === null ? !1 : Array.isArray(t) && Array.isArray(e) ? t.length !== e.length ? !1 : f(t[Symbol.iterator](), e[Symbol.iterator]()) : t instanceof Map && e instanceof Map || t instanceof Set && e instanceof Set ? t.size !== e.size ? !1 : f(t.entries(), e.entries()) : p(t) && p(e) ? f(Object.entries(t)[Symbol.iterator](), Object.entries(e)[Symbol.iterator]()) : !1;
}
function f(t, e) {
    do {
        let r = t.next(), s = e.next();
        if (r.done && s.done) return !0;
        if (r.done || s.done || !Object.is(r.value, s.value)) return !1;
    }while (!0)
}
function p(t) {
    if (Object.prototype.toString.call(t) !== "[object Object]") return !1;
    let e = Object.getPrototypeOf(t);
    return e === null || Object.getPrototypeOf(e) === null;
}
function k(t) {
    let [e, r] = t(), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])();
    return (...l)=>{
        e(...l), s.dispose(), s.microTask(r);
    };
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/match.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "match",
    ()=>u
]);
function u(r, n, ...a) {
    if (r in n) {
        let e = n[r];
        return typeof e == "function" ? e(...a) : e;
    }
    let t = new Error(`Tried to handle "${r}" but there is no handler defined. Only defined handlers are: ${Object.keys(n).map((e)=>`"${e}"`).join(", ")}.`);
    throw Error.captureStackTrace && Error.captureStackTrace(t, u), t;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/machines/stack-machine.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActionTypes",
    ()=>k,
    "stackMachines",
    ()=>x
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/machine.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$default$2d$map$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/default-map.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/match.js [app-client] (ecmascript)");
var a = Object.defineProperty;
var r = (e, c, t)=>c in e ? a(e, c, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[c] = t;
var p = (e, c, t)=>(r(e, typeof c != "symbol" ? c + "" : c, t), t);
;
;
;
var k = ((t)=>(t[t.Push = 0] = "Push", t[t.Pop = 1] = "Pop", t))(k || {});
let y = {
    [0] (e, c) {
        let t = c.id, s = e.stack, i = e.stack.indexOf(t);
        if (i !== -1) {
            let n = e.stack.slice();
            return n.splice(i, 1), n.push(t), s = n, {
                ...e,
                stack: s
            };
        }
        return {
            ...e,
            stack: [
                ...e.stack,
                t
            ]
        };
    },
    [1] (e, c) {
        let t = c.id, s = e.stack.indexOf(t);
        if (s === -1) return e;
        let i = e.stack.slice();
        return i.splice(s, 1), {
            ...e,
            stack: i
        };
    }
};
class o extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Machine"] {
    constructor(){
        super(...arguments);
        p(this, "actions", {
            push: (t)=>this.send({
                    type: 0,
                    id: t
                }),
            pop: (t)=>this.send({
                    type: 1,
                    id: t
                })
        });
        p(this, "selectors", {
            isTop: (t, s)=>t.stack[t.stack.length - 1] === s,
            inStack: (t, s)=>t.stack.includes(s)
        });
    }
    static new() {
        return new o({
            stack: []
        });
    }
    reduce(t, s) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(s.type, y, t, s);
    }
}
const x = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$default$2d$map$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultMap"](()=>o.new());
;
}),
"[project]/node_modules/@headlessui/react/dist/react-glue.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSlice",
    ()=>S
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$with$2d$selector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/use-sync-external-store/with-selector.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/machine.js [app-client] (ecmascript)");
;
;
;
function S(e, n, r = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shallowEqual"]) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$with$2d$selector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStoreWithSelector"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((i)=>e.subscribe(s, i)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(()=>e.state), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(()=>e.state), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(n), r);
}
function s(e) {
    return e;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-is-top-layer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useIsTopLayer",
    ()=>I
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machines$2f$stack$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/machines/stack-machine.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/react-glue.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
;
;
;
;
function I(o, s) {
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), r = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machines$2f$stack$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stackMachines"].get(s), [i, c] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(r, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((e)=>[
            r.selectors.isTop(e, t),
            r.selectors.inStack(e, t)
        ], [
        r,
        t
    ]));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        if (o) return r.actions.push(t), ()=>r.actions.pop(t);
    }, [
        r,
        o,
        t
    ]), o ? c ? i : !0 : !1;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-inert-others.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useInertOthers",
    ()=>y
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/owner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$is$2d$top$2d$layer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-is-top-layer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
;
;
;
;
let f = new Map, u = new Map;
function h(t) {
    var e;
    let r = (e = u.get(t)) != null ? e : 0;
    return u.set(t, r + 1), r !== 0 ? ()=>m(t) : (f.set(t, {
        "aria-hidden": t.getAttribute("aria-hidden"),
        inert: t.inert
    }), t.setAttribute("aria-hidden", "true"), t.inert = !0, ()=>m(t));
}
function m(t) {
    var i;
    let r = (i = u.get(t)) != null ? i : 1;
    if (r === 1 ? u.delete(t) : u.set(t, r - 1), r !== 1) return;
    let e = f.get(t);
    e && (e["aria-hidden"] === null ? t.removeAttribute("aria-hidden") : t.setAttribute("aria-hidden", e["aria-hidden"]), t.inert = e.inert, f.delete(t));
}
function y(t, { allowed: r, disallowed: e } = {}) {
    let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$is$2d$top$2d$layer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsTopLayer"])(t, "inert-others");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        var d, c;
        if (!i) return;
        let a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])();
        for (let n of (d = e == null ? void 0 : e()) != null ? d : [])n && a.add(h(n));
        let s = (c = r == null ? void 0 : r()) != null ? c : [];
        for (let n of s){
            if (!n) continue;
            let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnerDocument"])(n);
            if (!l) continue;
            let o = n.parentElement;
            for(; o && o !== l.body;){
                for (let p of o.children)s.some((E)=>p.contains(E)) || a.add(h(p));
                o = o.parentElement;
            }
        }
        return a.dispose;
    }, [
        i,
        r,
        e
    ]);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-on-disappear.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useOnDisappear",
    ()=>p
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-latest-value.js [app-client] (ecmascript)");
;
;
;
;
function p(s, n, o) {
    let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLatestValue"])((t)=>{
        let e = t.getBoundingClientRect();
        e.x === 0 && e.y === 0 && e.width === 0 && e.height === 0 && o();
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!s) return;
        let t = n === null ? null : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"](n) ? n : n.current;
        if (!t) return;
        let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])();
        if (typeof ResizeObserver != "undefined") {
            let r = new ResizeObserver(()=>i.current(t));
            r.observe(t), e.add(()=>r.disconnect());
        }
        if (typeof IntersectionObserver != "undefined") {
            let r = new IntersectionObserver(()=>i.current(t));
            r.observe(t), e.add(()=>r.disconnect());
        }
        return ()=>e.dispose();
    }, [
        n,
        i,
        s
    ]);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/focus-management.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Focus",
    ()=>T,
    "FocusResult",
    ()=>A,
    "FocusableMode",
    ()=>I,
    "focusElement",
    ()=>w,
    "focusFrom",
    ()=>R,
    "focusIn",
    ()=>v,
    "focusableSelector",
    ()=>E,
    "getAutoFocusableElements",
    ()=>h,
    "getFocusableElements",
    ()=>x,
    "isFocusableElement",
    ()=>H,
    "restoreFocusIfNecessary",
    ()=>K,
    "sortByDomNode",
    ()=>G
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/match.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/owner.js [app-client] (ecmascript)");
;
;
;
;
let E = [
    "[contentEditable=true]",
    "[tabindex]",
    "a[href]",
    "area[href]",
    "button:not([disabled])",
    "iframe",
    "input:not([disabled])",
    "select:not([disabled])",
    "details>summary",
    "textarea:not([disabled])"
].map((e)=>`${e}:not([tabindex='-1'])`).join(","), S = [
    "[data-autofocus]"
].map((e)=>`${e}:not([tabindex='-1'])`).join(",");
var T = ((o)=>(o[o.First = 1] = "First", o[o.Previous = 2] = "Previous", o[o.Next = 4] = "Next", o[o.Last = 8] = "Last", o[o.WrapAround = 16] = "WrapAround", o[o.NoScroll = 32] = "NoScroll", o[o.AutoFocus = 64] = "AutoFocus", o))(T || {}), A = ((n)=>(n[n.Error = 0] = "Error", n[n.Overflow = 1] = "Overflow", n[n.Success = 2] = "Success", n[n.Underflow = 3] = "Underflow", n))(A || {}), O = ((t)=>(t[t.Previous = -1] = "Previous", t[t.Next = 1] = "Next", t))(O || {});
function x(e = document.body) {
    return e == null ? [] : Array.from(e.querySelectorAll(E)).sort((r, t)=>Math.sign((r.tabIndex || Number.MAX_SAFE_INTEGER) - (t.tabIndex || Number.MAX_SAFE_INTEGER)));
}
function h(e = document.body) {
    return e == null ? [] : Array.from(e.querySelectorAll(S)).sort((r, t)=>Math.sign((r.tabIndex || Number.MAX_SAFE_INTEGER) - (t.tabIndex || Number.MAX_SAFE_INTEGER)));
}
var I = ((t)=>(t[t.Strict = 0] = "Strict", t[t.Loose = 1] = "Loose", t))(I || {});
function H(e, r = 0) {
    var t;
    return e === ((t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnerDocument"])(e)) == null ? void 0 : t.body) ? !1 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(r, {
        [0] () {
            return e.matches(E);
        },
        [1] () {
            let l = e;
            for(; l !== null;){
                if (l.matches(E)) return !0;
                l = l.parentElement;
            }
            return !1;
        }
    });
}
function K(e) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])().nextFrame(()=>{
        let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getActiveElement"])(e);
        r && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLorSVGElement"](r) && !H(r, 0) && w(e);
    });
}
var g = ((t)=>(t[t.Keyboard = 0] = "Keyboard", t[t.Mouse = 1] = "Mouse", t))(g || {});
typeof window != "undefined" && typeof document != "undefined" && (document.addEventListener("keydown", (e)=>{
    e.metaKey || e.altKey || e.ctrlKey || (document.documentElement.dataset.headlessuiFocusVisible = "");
}, !0), document.addEventListener("click", (e)=>{
    e.detail === 1 ? delete document.documentElement.dataset.headlessuiFocusVisible : e.detail === 0 && (document.documentElement.dataset.headlessuiFocusVisible = "");
}, !0));
function w(e) {
    e == null || e.focus({
        preventScroll: !0
    });
}
let _ = [
    "textarea",
    "input"
].join(",");
function P(e) {
    var r, t;
    return (t = (r = e == null ? void 0 : e.matches) == null ? void 0 : r.call(e, _)) != null ? t : !1;
}
function G(e, r = (t)=>t) {
    return e.slice().sort((t, l)=>{
        let n = r(t), a = r(l);
        if (n === null || a === null) return 0;
        let u = n.compareDocumentPosition(a);
        return u & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : u & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
    });
}
function R(e, r, t = e === null ? document.body : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRootNode"])(e)) {
    return v(x(t), r, {
        relativeTo: e
    });
}
function v(e, r, { sorted: t = !0, relativeTo: l = null, skipElements: n = [] } = {}) {
    let a = Array.isArray(e) ? e.length > 0 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRootNode"])(e[0]) : document : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRootNode"])(e), u = Array.isArray(e) ? t ? G(e) : e : r & 64 ? h(e) : x(e);
    n.length > 0 && u.length > 1 && (u = u.filter((i)=>!n.some((d)=>d != null && "current" in d ? (d == null ? void 0 : d.current) === i : d === i))), l = l != null ? l : a == null ? void 0 : a.activeElement;
    let o = (()=>{
        if (r & 5) return 1;
        if (r & 10) return -1;
        throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
    })(), M = (()=>{
        if (r & 1) return 0;
        if (r & 2) return Math.max(0, u.indexOf(l)) - 1;
        if (r & 4) return Math.max(0, u.indexOf(l)) + 1;
        if (r & 8) return u.length - 1;
        throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
    })(), N = r & 32 ? {
        preventScroll: !0
    } : {}, m = 0, c = u.length, s;
    do {
        if (m >= c || m + c <= 0) return 0;
        let i = M + m;
        if (r & 16) i = (i + c) % c;
        else {
            if (i < 0) return 3;
            if (i >= c) return 1;
        }
        s = u[i], s == null || s.focus(N), m += o;
    }while (s !== (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getActiveElement"])(s))
    return r & 6 && P(s) && s.select(), 2;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/platform.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isAndroid",
    ()=>i,
    "isIOS",
    ()=>t,
    "isMobile",
    ()=>n
]);
function t() {
    return /iPhone/gi.test(window.navigator.platform) || /Mac/gi.test(window.navigator.platform) && window.navigator.maxTouchPoints > 0;
}
function i() {
    return /Android/gi.test(window.navigator.userAgent);
}
function n() {
    return t() || i();
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-document-event.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDocumentEvent",
    ()=>i
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-latest-value.js [app-client] (ecmascript)");
;
;
function i(t, e, o, n) {
    let u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLatestValue"])(o);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!t) return;
        function r(m) {
            u.current(m);
        }
        return document.addEventListener(e, r, n), ()=>document.removeEventListener(e, r, n);
    }, [
        t,
        e,
        n
    ]);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-window-event.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useWindowEvent",
    ()=>s
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-latest-value.js [app-client] (ecmascript)");
;
;
function s(t, e, o, n) {
    let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLatestValue"])(o);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!t) return;
        function r(d) {
            i.current(d);
        }
        return window.addEventListener(e, r, n), ()=>window.removeEventListener(e, r, n);
    }, [
        t,
        e,
        n
    ]);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-outside-click.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useOutsideClick",
    ()=>k
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/focus-management.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/platform.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$document$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-document-event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-latest-value.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$window$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-window-event.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
const C = 30;
function k(o, f, h) {
    let m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLatestValue"])(h), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(function(e, c) {
        if (e.defaultPrevented) return;
        let r = c(e);
        if (r === null || !r.getRootNode().contains(r) || !r.isConnected) return;
        let M = function u(n) {
            return typeof n == "function" ? u(n()) : Array.isArray(n) || n instanceof Set ? n : [
                n
            ];
        }(f);
        for (let u of M)if (u !== null && (u.contains(r) || e.composed && e.composedPath().includes(u))) return;
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFocusableElement"])(r, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FocusableMode"].Loose) && r.tabIndex !== -1 && e.preventDefault(), m.current(e, r);
    }, [
        m,
        f
    ]), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$document$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentEvent"])(o, "pointerdown", (t)=>{
        var e, c;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMobile"])() || (i.current = ((c = (e = t.composedPath) == null ? void 0 : e.call(t)) == null ? void 0 : c[0]) || t.target);
    }, !0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$document$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentEvent"])(o, "pointerup", (t)=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMobile"])() || !i.current) return;
        let e = i.current;
        return i.current = null, s(t, ()=>e);
    }, !0);
    let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        x: 0,
        y: 0
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$document$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentEvent"])(o, "touchstart", (t)=>{
        l.current.x = t.touches[0].clientX, l.current.y = t.touches[0].clientY;
    }, !0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$document$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentEvent"])(o, "touchend", (t)=>{
        let e = {
            x: t.changedTouches[0].clientX,
            y: t.changedTouches[0].clientY
        };
        if (!(Math.abs(e.x - l.current.x) >= C || Math.abs(e.y - l.current.y) >= C)) return s(t, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLorSVGElement"](t.target) ? t.target : null);
    }, !0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$window$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWindowEvent"])(o, "blur", (t)=>s(t, ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLIframeElement"](window.document.activeElement) ? window.document.activeElement : null), !0);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-owner.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useOwnerDocument",
    ()=>u,
    "useRootDocument",
    ()=>c
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/owner.js [app-client] (ecmascript)");
;
;
function u(...e) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnerDocument"])(...e), [
        ...e
    ]);
}
function c(...e) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRootNode"])(...e), [
        ...e
    ]);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-quick-release.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Action",
    ()=>S,
    "useQuickRelease",
    ()=>L
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$document$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-document-event.js [app-client] (ecmascript)");
;
;
;
var H = ((e)=>(e[e.Ignore = 0] = "Ignore", e[e.Select = 1] = "Select", e[e.Close = 2] = "Close", e))(H || {});
const S = {
    Ignore: {
        kind: 0
    },
    Select: (r)=>({
            kind: 1,
            target: r
        }),
    Close: {
        kind: 2
    }
}, M = 200, f = 5;
function L(r, { trigger: n, action: T, close: e, select: p }) {
    let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$document$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentEvent"])(r && n !== null, "pointerdown", (t)=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNode"](t == null ? void 0 : t.target) && n != null && n.contains(t.target) && (i.current = t.x, u.current = t.y, l.current = t.timeStamp);
    }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$document$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentEvent"])(r && n !== null, "pointerup", (t)=>{
        var s, m;
        let c = l.current;
        if (c === null || (l.current = null, !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLorSVGElement"](t.target)) || Math.abs(t.x - ((s = i.current) != null ? s : t.x)) < f && Math.abs(t.y - ((m = u.current) != null ? m : t.y)) < f) return;
        let a = T(t);
        switch(a.kind){
            case 0:
                return;
            case 1:
                {
                    t.timeStamp - c > M && (p(a.target), e());
                    break;
                }
            case 2:
                {
                    e();
                    break;
                }
        }
    }, {
        capture: !0
    });
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-resolve-button-type.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useResolveButtonType",
    ()=>e
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function e(t, u) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        var n;
        if (t.type) return t.type;
        let r = (n = t.as) != null ? n : "button";
        if (typeof r == "string" && r.toLowerCase() === "button" || (u == null ? void 0 : u.tagName) === "BUTTON" && !u.hasAttribute("type")) return "button";
    }, [
        t.type,
        t.as,
        u
    ]);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-store.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStore",
    ()=>o
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function o(t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(t.subscribe, t.getSnapshot, t.getSnapshot);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/store.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStore",
    ()=>a
]);
function a(o, r) {
    let t = o(), n = new Set;
    return {
        getSnapshot () {
            return t;
        },
        subscribe (e) {
            return n.add(e), ()=>n.delete(e);
        },
        dispatch (e, ...s) {
            let i = r[e].call(t, ...s);
            i && (t = i, n.forEach((c)=>c()));
        }
    };
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/adjust-scrollbar-padding.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "adjustScrollbarPadding",
    ()=>d
]);
function d() {
    let r;
    return {
        before ({ doc: e }) {
            var l;
            let o = e.documentElement, t = (l = e.defaultView) != null ? l : window;
            r = Math.max(0, t.innerWidth - o.clientWidth);
        },
        after ({ doc: e, d: o }) {
            let t = e.documentElement, l = Math.max(0, t.clientWidth - t.offsetWidth), n = Math.max(0, r - l);
            o.style(t, "paddingRight", `${n}px`);
        }
    };
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/handle-ios-locking.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "handleIOSLocking",
    ()=>w
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/platform.js [app-client] (ecmascript)");
;
;
;
function w() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isIOS"])() ? {
        before ({ doc: o, d: r, meta: m }) {
            function a(s) {
                for (let l of m().containers)for (let c of l())if (c.contains(s)) return !0;
                return !1;
            }
            r.microTask(()=>{
                var c;
                if (window.getComputedStyle(o.documentElement).scrollBehavior !== "auto") {
                    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])();
                    t.style(o.documentElement, "scrollBehavior", "auto"), r.add(()=>r.microTask(()=>t.dispose()));
                }
                let s = (c = window.scrollY) != null ? c : window.pageYOffset, l = null;
                r.addEventListener(o, "click", (t)=>{
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLorSVGElement"](t.target)) try {
                        let e = t.target.closest("a");
                        if (!e) return;
                        let { hash: n } = new URL(e.href), f = o.querySelector(n);
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLorSVGElement"](f) && !a(f) && (l = f);
                    } catch  {}
                }, !0), r.group((t)=>{
                    r.addEventListener(o, "touchstart", (e)=>{
                        if (t.dispose(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLorSVGElement"](e.target) && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasInlineStyle"](e.target)) if (a(e.target)) {
                            let n = e.target;
                            for(; n.parentElement && a(n.parentElement);)n = n.parentElement;
                            t.style(n, "overscrollBehavior", "contain");
                        } else t.style(e.target, "touchAction", "none");
                    });
                }), r.addEventListener(o, "touchmove", (t)=>{
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLorSVGElement"](t.target)) {
                        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLInputElement"](t.target)) return;
                        if (a(t.target)) {
                            let e = t.target;
                            for(; e.parentElement && e.dataset.headlessuiPortal !== "" && !(e.scrollHeight > e.clientHeight || e.scrollWidth > e.clientWidth);)e = e.parentElement;
                            e.dataset.headlessuiPortal === "" && t.preventDefault();
                        } else t.preventDefault();
                    }
                }, {
                    passive: !1
                }), r.add(()=>{
                    var e;
                    let t = (e = window.scrollY) != null ? e : window.pageYOffset;
                    s !== t && window.scrollTo(0, s), l && l.isConnected && (l.scrollIntoView({
                        block: "nearest"
                    }), l = null);
                });
            });
        }
    } : {};
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/prevent-scroll.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "preventScroll",
    ()=>r
]);
function r() {
    return {
        before ({ doc: e, d: o }) {
            o.style(e.documentElement, "overflow", "hidden");
        }
    };
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/overflow-store.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "overflows",
    ()=>c
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/store.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$adjust$2d$scrollbar$2d$padding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/adjust-scrollbar-padding.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$handle$2d$ios$2d$locking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/handle-ios-locking.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$prevent$2d$scroll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/prevent-scroll.js [app-client] (ecmascript)");
;
;
;
;
;
function r(e) {
    let o = {};
    for (let t of e)Object.assign(o, t(o));
    return o;
}
let c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStore"])(()=>new Map, {
    PUSH (e, o) {
        var n;
        let t = (n = this.get(e)) != null ? n : {
            doc: e,
            count: 0,
            d: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])(),
            meta: new Set,
            computedMeta: {}
        };
        return t.count++, t.meta.add(o), t.computedMeta = r(t.meta), this.set(e, t), this;
    },
    POP (e, o) {
        let t = this.get(e);
        return t && (t.count--, t.meta.delete(o), t.computedMeta = r(t.meta)), this;
    },
    SCROLL_PREVENT (e) {
        let o = {
            doc: e.doc,
            d: e.d,
            meta () {
                return e.computedMeta;
            }
        }, t = [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$handle$2d$ios$2d$locking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["handleIOSLocking"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$adjust$2d$scrollbar$2d$padding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["adjustScrollbarPadding"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$prevent$2d$scroll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preventScroll"])()
        ];
        t.forEach(({ before: n })=>n == null ? void 0 : n(o)), t.forEach(({ after: n })=>n == null ? void 0 : n(o));
    },
    SCROLL_ALLOW ({ d: e }) {
        e.dispose();
    },
    TEARDOWN ({ doc: e }) {
        this.delete(e);
    }
});
c.subscribe(()=>{
    let e = c.getSnapshot(), o = new Map;
    for (let [t] of e)o.set(t, t.documentElement.style.overflow);
    for (let t of e.values()){
        let n = o.get(t.doc) === "hidden", a = t.count !== 0;
        (a && !n || !a && n) && c.dispatch(t.count > 0 ? "SCROLL_PREVENT" : "SCROLL_ALLOW", t), t.count === 0 && c.dispatch("TEARDOWN", t);
    }
});
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/use-document-overflow.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDocumentOverflowLockedEffect",
    ()=>a
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-store.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$overflow$2d$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/overflow-store.js [app-client] (ecmascript)");
;
;
;
function a(r, e, n = ()=>({
        containers: []
    })) {
    let f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$overflow$2d$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["overflows"]), o = e ? f.get(e) : void 0, i = o ? o.count > 0 : !1;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        if (!(!e || !r)) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$overflow$2d$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["overflows"].dispatch("PUSH", e, n), ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$overflow$2d$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["overflows"].dispatch("POP", e, n);
    }, [
        r,
        e
    ]), i;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-scroll-lock.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useScrollLock",
    ()=>f
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$use$2d$document$2d$overflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/document-overflow/use-document-overflow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$is$2d$top$2d$layer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-is-top-layer.js [app-client] (ecmascript)");
;
;
function f(e, c, n = ()=>[
        document.body
    ]) {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$is$2d$top$2d$layer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsTopLayer"])(e, "scroll-lock");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$document$2d$overflow$2f$use$2d$document$2d$overflow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentOverflowLockedEffect"])(r, c, (t)=>{
        var o;
        return {
            containers: [
                ...(o = t.containers) != null ? o : [],
                n
            ]
        };
    });
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-slot.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSlot",
    ()=>n
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function n(e) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>e, Object.values(e));
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-sync-refs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "optionalRef",
    ()=>T,
    "useSyncRefs",
    ()=>y
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
;
;
let u = Symbol();
function T(t, n = !0) {
    return Object.assign(t, {
        [u]: n
    });
}
function y(...t) {
    let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        n.current = t;
    }, [
        t
    ]);
    let c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((e)=>{
        for (let o of n.current)o != null && (typeof o == "function" ? o(e) : o.current = e);
    });
    return t.every((e)=>e == null || (e == null ? void 0 : e[u])) ? void 0 : c;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/get-text-value.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getTextValue",
    ()=>F
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
;
let a = /([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g;
function o(e) {
    var l, n;
    let i = (l = e.innerText) != null ? l : "", t = e.cloneNode(!0);
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"](t)) return i;
    let u = !1;
    for (let f of t.querySelectorAll('[hidden],[aria-hidden],[role="img"]'))f.remove(), u = !0;
    let r = u ? (n = t.innerText) != null ? n : "" : i;
    return a.test(r) && (r = r.replace(a, "")), r;
}
function F(e) {
    let i = e.getAttribute("aria-label");
    if (typeof i == "string") return i.trim();
    let t = e.getAttribute("aria-labelledby");
    if (t) {
        let u = t.split(" ").map((r)=>{
            let l = document.getElementById(r);
            if (l) {
                let n = l.getAttribute("aria-label");
                return typeof n == "string" ? n.trim() : o(l).trim();
            }
            return null;
        }).filter(Boolean);
        if (u.length > 0) return u.join(", ");
    }
    return o(e).trim();
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-text-value.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTextValue",
    ()=>s
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$get$2d$text$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/get-text-value.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
;
;
;
function s(c) {
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(""), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])("");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(()=>{
        let e = c.current;
        if (!e) return "";
        let u = e.innerText;
        if (t.current === u) return r.current;
        let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$get$2d$text$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTextValue"])(e).trim().toLowerCase();
        return t.current = u, r.current = n, n;
    });
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-tracked-pointer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTrackedPointer",
    ()=>u
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function t(e) {
    return [
        e.screenX,
        e.screenY
    ];
}
function u() {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([
        -1,
        -1
    ]);
    return {
        wasMoved (r) {
            let n = t(r);
            return e.current[0] === n[0] && e.current[1] === n[1] ? !1 : (e.current = n, !0);
        },
        update (r) {
            e.current = t(r);
        }
    };
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-flags.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFlags",
    ()=>c
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function c(u = 0) {
    let [r, a] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(u), g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((e)=>a(e), []), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((e)=>a((l)=>l | e), []), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((e)=>(r & e) === e, [
        r
    ]), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((e)=>a((l)=>l & ~e), []), F = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((e)=>a((l)=>l ^ e), []);
    return {
        flags: r,
        setFlag: g,
        addFlag: s,
        hasFlag: m,
        removeFlag: n,
        toggleFlag: F
    };
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-transition.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "transitionDataAttributes",
    ()=>x,
    "useTransition",
    ()=>N
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$flags$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-flags.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
var T, S;
;
;
;
;
;
typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] != "undefined" && typeof globalThis != "undefined" && typeof Element != "undefined" && ((T = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] == null ? void 0 : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env) == null ? void 0 : T["NODE_ENV"]) === "test" && typeof ((S = Element == null ? void 0 : Element.prototype) == null ? void 0 : S.getAnimations) == "undefined" && (Element.prototype.getAnimations = function() {
    return console.warn([
        "Headless UI has polyfilled `Element.prototype.getAnimations` for your tests.",
        "Please install a proper polyfill e.g. `jsdom-testing-mocks`, to silence these warnings.",
        "",
        "Example usage:",
        "```js",
        "import { mockAnimationsApi } from 'jsdom-testing-mocks'",
        "mockAnimationsApi()",
        "```"
    ].join(`
`)), [];
});
var A = ((i)=>(i[i.None = 0] = "None", i[i.Closed = 1] = "Closed", i[i.Enter = 2] = "Enter", i[i.Leave = 4] = "Leave", i))(A || {});
function x(e) {
    let r = {};
    for(let t in e)e[t] === !0 && (r[`data-${t}`] = "");
    return r;
}
function N(e, r, t, n) {
    let [i, a] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t), { hasFlag: s, addFlag: o, removeFlag: l } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$flags$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFlags"])(e && i ? 3 : 0), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), E = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisposables"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        var d;
        if (e) {
            if (t && a(!0), !r) {
                t && o(3);
                return;
            }
            return (d = n == null ? void 0 : n.start) == null || d.call(n, t), C(r, {
                inFlight: u,
                prepare () {
                    f.current ? f.current = !1 : f.current = u.current, u.current = !0, !f.current && (t ? (o(3), l(4)) : (o(4), l(2)));
                },
                run () {
                    f.current ? t ? (l(3), o(4)) : (l(4), o(3)) : t ? l(1) : o(1);
                },
                done () {
                    var p;
                    f.current && D(r) || (u.current = !1, l(7), t || a(!1), (p = n == null ? void 0 : n.end) == null || p.call(n, t));
                }
            });
        }
    }, [
        e,
        t,
        r,
        E
    ]), e ? [
        i,
        {
            closed: s(1),
            enter: s(2),
            leave: s(4),
            transition: s(2) || s(4)
        }
    ] : [
        t,
        {
            closed: void 0,
            enter: void 0,
            leave: void 0,
            transition: void 0
        }
    ];
}
function C(e, { prepare: r, run: t, done: n, inFlight: i }) {
    let a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])();
    return j(e, {
        prepare: r,
        inFlight: i
    }), a.nextFrame(()=>{
        t(), a.requestAnimationFrame(()=>{
            a.add(M(e, n));
        });
    }), a.dispose;
}
function M(e, r) {
    var a, s;
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])();
    if (!e) return t.dispose;
    let n = !1;
    t.add(()=>{
        n = !0;
    });
    let i = (s = (a = e.getAnimations) == null ? void 0 : a.call(e).filter((o)=>o instanceof CSSTransition)) != null ? s : [];
    return i.length === 0 ? (r(), t.dispose) : (Promise.allSettled(i.map((o)=>o.finished)).then(()=>{
        n || r();
    }), t.dispose);
}
function j(e, { inFlight: r, prepare: t }) {
    if (r != null && r.current) {
        t();
        return;
    }
    let n = e.style.transition;
    e.style.transition = "none", t(), e.offsetHeight, e.style.transition = n;
}
function D(e) {
    var t, n;
    return ((n = (t = e.getAnimations) == null ? void 0 : t.call(e)) != null ? n : []).some((i)=>i instanceof CSSTransition && i.playState !== "finished");
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-tree-walker.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useTreeWalker",
    ()=>F
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/owner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
;
;
;
function F(c, { container: e, accept: t, walk: r }) {
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(r);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        o.current = t, l.current = r;
    }, [
        t,
        r
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        if (!e || !c) return;
        let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOwnerDocument"])(e);
        if (!n) return;
        let f = o.current, p = l.current, i = Object.assign((m)=>f(m), {
            acceptNode: f
        }), u = n.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, i, !1);
        for(; u.nextNode();)p(u.currentNode);
    }, [
        e,
        c,
        o,
        l
    ]);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/internal/floating.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FloatingProvider",
    ()=>Ae,
    "useFloatingPanel",
    ()=>Re,
    "useFloatingPanelProps",
    ()=>Te,
    "useFloatingReference",
    ()=>Fe,
    "useFloatingReferenceProps",
    ()=>be,
    "useResolvedAnchor",
    ()=>ye
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/react/dist/floating-ui.react.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
let y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    styles: void 0,
    setReference: ()=>{},
    setFloating: ()=>{},
    getReferenceProps: ()=>({}),
    getFloatingProps: ()=>({}),
    slot: {}
});
y.displayName = "FloatingContext";
let $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
$.displayName = "PlacementContext";
function ye(e) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>e ? typeof e == "string" ? {
            to: e
        } : e : null, [
        e
    ]);
}
function Fe() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(y).setReference;
}
function be() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(y).getReferenceProps;
}
function Te() {
    let { getFloatingProps: e, slot: t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(y);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((...n)=>Object.assign({}, e(...n), {
            "data-anchor": t.anchor
        }), [
        e,
        t
    ]);
}
function Re(e = null) {
    e === !1 && (e = null), typeof e == "string" && (e = {
        to: e
    });
    let t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])($), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>e, [
        JSON.stringify(e, (l, o)=>{
            var u;
            return (u = o == null ? void 0 : o.outerHTML) != null ? u : o;
        })
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        t == null || t(n != null ? n : null);
    }, [
        t,
        n
    ]);
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(y);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>[
            r.setFloating,
            e ? r.styles : {}
        ], [
        r.setFloating,
        e,
        r.styles
    ]);
}
let D = 4;
function Ae({ children: e, enabled: t = !0 }) {
    let [n, r] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [l, o] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0), u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [f, s] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    ce(f);
    let i = t && n !== null && f !== null, { to: F = "bottom", gap: E = 0, offset: A = 0, padding: c = 0, inner: h } = ge(n, f), [a, p = "center"] = F.split(" ");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        i && o(0);
    }, [
        i
    ]);
    let { refs: b, floatingStyles: S, context: g } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"])({
        open: i,
        placement: a === "selection" ? p === "center" ? "bottom" : `bottom-${p}` : p === "center" ? `${a}` : `${a}-${p}`,
        strategy: "absolute",
        transform: !1,
        middleware: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["offset"])({
                mainAxis: a === "selection" ? 0 : E,
                crossAxis: A
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["shift"])({
                padding: c
            }),
            a !== "selection" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flip"])({
                padding: c
            }),
            a === "selection" && h ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["inner"])({
                ...h,
                padding: c,
                overflowRef: u,
                offset: l,
                minItemsVisible: D,
                referenceOverflowThreshold: c,
                onFallbackChange (P) {
                    var L, N;
                    if (!P) return;
                    let d = g.elements.floating;
                    if (!d) return;
                    let M = parseFloat(getComputedStyle(d).scrollPaddingBottom) || 0, I = Math.min(D, d.childElementCount), W = 0, B = 0;
                    for (let m of (N = (L = g.elements.floating) == null ? void 0 : L.childNodes) != null ? N : [])if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"](m)) {
                        let x = m.offsetTop, k = x + m.clientHeight + M, H = d.scrollTop, U = H + d.clientHeight;
                        if (x >= H && k <= U) I--;
                        else {
                            B = Math.max(0, Math.min(k, U) - Math.max(x, H)), W = m.clientHeight;
                            break;
                        }
                    }
                    I >= 1 && o((m)=>{
                        let x = W * I - B + M;
                        return m >= x ? m : x;
                    });
                }
            }) : null,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["size"])({
                padding: c,
                apply ({ availableWidth: P, availableHeight: d, elements: M }) {
                    Object.assign(M.floating.style, {
                        overflow: "auto",
                        maxWidth: `${P}px`,
                        maxHeight: `min(var(--anchor-max-height, 100vh), ${d}px)`
                    });
                }
            })
        ].filter(Boolean),
        whileElementsMounted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoUpdate"]
    }), [w = a, V = p] = g.placement.split("-");
    a === "selection" && (w = "selection");
    let G = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            anchor: [
                w,
                V
            ].filter(Boolean).join(" ")
        }), [
        w,
        V
    ]), K = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInnerOffset"])(g, {
        overflowRef: u,
        onChange: o
    }), { getReferenceProps: Q, getFloatingProps: X } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInteractions"])([
        K
    ]), Y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((P)=>{
        s(P), b.setFloating(P);
    });
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]($.Provider, {
        value: r
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](y.Provider, {
        value: {
            setFloating: Y,
            setReference: b.setReference,
            styles: S,
            getReferenceProps: Q,
            getFloatingProps: X,
            slot: G
        }
    }, e));
}
function ce(e) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        if (!e) return;
        let t = new MutationObserver(()=>{
            let n = window.getComputedStyle(e).maxHeight, r = parseFloat(n);
            if (isNaN(r)) return;
            let l = parseInt(n);
            isNaN(l) || r !== l && (e.style.maxHeight = `${Math.ceil(r)}px`);
        });
        return t.observe(e, {
            attributes: !0,
            attributeFilter: [
                "style"
            ]
        }), ()=>{
            t.disconnect();
        };
    }, [
        e
    ]);
}
function ge(e, t) {
    var o, u, f;
    let n = O((o = e == null ? void 0 : e.gap) != null ? o : "var(--anchor-gap, 0)", t), r = O((u = e == null ? void 0 : e.offset) != null ? u : "var(--anchor-offset, 0)", t), l = O((f = e == null ? void 0 : e.padding) != null ? f : "var(--anchor-padding, 0)", t);
    return {
        ...e,
        gap: n,
        offset: r,
        padding: l
    };
}
function O(e, t, n = void 0) {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisposables"])(), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((s, i)=>{
        if (s == null) return [
            n,
            null
        ];
        if (typeof s == "number") return [
            s,
            null
        ];
        if (typeof s == "string") {
            if (!i) return [
                n,
                null
            ];
            let F = J(s, i);
            return [
                F,
                (E)=>{
                    let A = q(s);
                    {
                        let c = A.map((h)=>window.getComputedStyle(i).getPropertyValue(h));
                        r.requestAnimationFrame(function h() {
                            r.nextFrame(h);
                            let a = !1;
                            for (let [b, S] of A.entries()){
                                let g = window.getComputedStyle(i).getPropertyValue(S);
                                if (c[b] !== g) {
                                    c[b] = g, a = !0;
                                    break;
                                }
                            }
                            if (!a) return;
                            let p = J(s, i);
                            F !== p && (E(p), F = p);
                        });
                    }
                    return r.dispose;
                }
            ];
        }
        return [
            n,
            null
        ];
    }), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>l(e, t)[0], [
        e,
        t
    ]), [u = o, f] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        let [s, i] = l(e, t);
        if (f(s), !!i) return i(f);
    }, [
        e,
        t
    ]), u;
}
function q(e) {
    let t = /var\((.*)\)/.exec(e);
    if (t) {
        let n = t[1].indexOf(",");
        if (n === -1) return [
            t[1]
        ];
        let r = t[1].slice(0, n).trim(), l = t[1].slice(n + 1).trim();
        return l ? [
            r,
            ...q(l)
        ] : [
            r
        ];
    }
    return [];
}
function J(e, t) {
    let n = document.createElement("div");
    t.appendChild(n), n.style.setProperty("margin-top", "0px", "important"), n.style.setProperty("margin-top", e, "important");
    let r = parseFloat(window.getComputedStyle(n).marginTop) || 0;
    return t.removeChild(n), r;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/internal/open-closed.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OpenClosedProvider",
    ()=>c,
    "ResetOpenClosedProvider",
    ()=>s,
    "State",
    ()=>i,
    "useOpenClosed",
    ()=>u
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
n.displayName = "OpenClosedContext";
var i = ((e)=>(e[e.Open = 1] = "Open", e[e.Closed = 2] = "Closed", e[e.Closing = 4] = "Closing", e[e.Opening = 8] = "Opening", e))(i || {});
function u() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(n);
}
function c({ value: o, children: t }) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(n.Provider, {
        value: o
    }, t);
}
function s({ children: o }) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(n.Provider, {
        value: null
    }, o);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/calculate-active-index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Focus",
    ()=>c,
    "calculateActiveIndex",
    ()=>f
]);
function u(l) {
    throw new Error("Unexpected object: " + l);
}
var c = ((i)=>(i[i.First = 0] = "First", i[i.Previous = 1] = "Previous", i[i.Next = 2] = "Next", i[i.Last = 3] = "Last", i[i.Specific = 4] = "Specific", i[i.Nothing = 5] = "Nothing", i))(c || {});
function f(l, n) {
    let t = n.resolveItems();
    if (t.length <= 0) return null;
    let r = n.resolveActiveIndex(), s = r != null ? r : -1;
    switch(l.focus){
        case 0:
            {
                for(let e = 0; e < t.length; ++e)if (!n.resolveDisabled(t[e], e, t)) return e;
                return r;
            }
        case 1:
            {
                s === -1 && (s = t.length);
                for(let e = s - 1; e >= 0; --e)if (!n.resolveDisabled(t[e], e, t)) return e;
                return r;
            }
        case 2:
            {
                for(let e = s + 1; e < t.length; ++e)if (!n.resolveDisabled(t[e], e, t)) return e;
                return r;
            }
        case 3:
            {
                for(let e = t.length - 1; e >= 0; --e)if (!n.resolveDisabled(t[e], e, t)) return e;
                return r;
            }
        case 4:
            {
                for(let e = 0; e < t.length; ++e)if (n.resolveId(t[e], e, t) === l.id) return e;
                return r;
            }
        case 5:
            return null;
        default:
            u(l);
    }
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/class-names.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "classNames",
    ()=>t
]);
function t(...r) {
    return Array.from(new Set(r.flatMap((n)=>typeof n == "string" ? n.split(" ") : []))).filter(Boolean).join(" ");
}
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/render.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RenderFeatures",
    ()=>A,
    "RenderStrategy",
    ()=>C,
    "compact",
    ()=>m,
    "forwardRefWithAs",
    ()=>Y,
    "isFragment",
    ()=>b,
    "isFragmentInstance",
    ()=>D,
    "mergeProps",
    ()=>V,
    "useRender",
    ()=>K
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$class$2d$names$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/class-names.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/match.js [app-client] (ecmascript)");
;
;
;
var A = ((a)=>(a[a.None = 0] = "None", a[a.RenderStrategy = 1] = "RenderStrategy", a[a.Static = 2] = "Static", a))(A || {}), C = ((e)=>(e[e.Unmount = 0] = "Unmount", e[e.Hidden = 1] = "Hidden", e))(C || {});
function K() {
    let n = $();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((r)=>U({
            mergeRefs: n,
            ...r
        }), [
        n
    ]);
}
function U({ ourProps: n, theirProps: r, slot: e, defaultTag: a, features: s, visible: t = !0, name: l, mergeRefs: i }) {
    i = i != null ? i : I;
    let o = P(r, n);
    if (t) return F(o, e, a, l, i);
    let y = s != null ? s : 0;
    if (y & 2) {
        let { static: f = !1, ...u } = o;
        if (f) return F(u, e, a, l, i);
    }
    if (y & 1) {
        let { unmount: f = !0, ...u } = o;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(f ? 0 : 1, {
            [0] () {
                return null;
            },
            [1] () {
                return F({
                    ...u,
                    hidden: !0,
                    style: {
                        display: "none"
                    }
                }, e, a, l, i);
            }
        });
    }
    return F(o, e, a, l, i);
}
function F(n, r = {}, e, a, s) {
    let { as: t = e, children: l, refName: i = "ref", ...o } = h(n, [
        "unmount",
        "static"
    ]), y = n.ref !== void 0 ? {
        [i]: n.ref
    } : {}, f = typeof l == "function" ? l(r) : l;
    "className" in o && o.className && typeof o.className == "function" && (o.className = o.className(r)), o["aria-labelledby"] && o["aria-labelledby"] === o.id && (o["aria-labelledby"] = void 0);
    let u = {};
    if (r) {
        let d = !1, p = [];
        for (let [c, T] of Object.entries(r))typeof T == "boolean" && (d = !0), T === !0 && p.push(c.replace(/([A-Z])/g, (g)=>`-${g.toLowerCase()}`));
        if (d) {
            u["data-headlessui-state"] = p.join(" ");
            for (let c of p)u[`data-${c}`] = "";
        }
    }
    if (b(t) && (Object.keys(m(o)).length > 0 || Object.keys(m(u)).length > 0)) if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(f) || Array.isArray(f) && f.length > 1 || D(f)) {
        if (Object.keys(m(o)).length > 0) throw new Error([
            'Passing props on "Fragment"!',
            "",
            `The current component <${a} /> is rendering a "Fragment".`,
            "However we need to passthrough the following props:",
            Object.keys(m(o)).concat(Object.keys(m(u))).map((d)=>`  - ${d}`).join(`
`),
            "",
            "You can apply a few solutions:",
            [
                'Add an `as="..."` prop, to ensure that we render an actual element instead of a "Fragment".',
                "Render a single element as the child so that we can forward the props onto that element."
            ].map((d)=>`  - ${d}`).join(`
`)
        ].join(`
`));
    } else {
        let d = f.props, p = d == null ? void 0 : d.className, c = typeof p == "function" ? (...R)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$class$2d$names$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["classNames"])(p(...R), o.className) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$class$2d$names$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["classNames"])(p, o.className), T = c ? {
            className: c
        } : {}, g = P(f.props, m(h(o, [
            "ref"
        ])));
        for(let R in u)R in g && delete u[R];
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(f, Object.assign({}, g, u, y, {
            ref: s(H(f), y.ref)
        }, T));
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(t, Object.assign({}, h(o, [
        "ref"
    ]), !b(t) && y, !b(t) && u), f);
}
function $() {
    let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((e)=>{
        for (let a of n.current)a != null && (typeof a == "function" ? a(e) : a.current = e);
    }, []);
    return (...e)=>{
        if (!e.every((a)=>a == null)) return n.current = e, r;
    };
}
function I(...n) {
    return n.every((r)=>r == null) ? void 0 : (r)=>{
        for (let e of n)e != null && (typeof e == "function" ? e(r) : e.current = r);
    };
}
function P(...n) {
    var a;
    if (n.length === 0) return {};
    if (n.length === 1) return n[0];
    let r = {}, e = {};
    for (let s of n)for(let t in s)t.startsWith("on") && typeof s[t] == "function" ? ((a = e[t]) != null || (e[t] = []), e[t].push(s[t])) : r[t] = s[t];
    if (r.disabled || r["aria-disabled"]) for(let s in e)/^(on(?:Click|Pointer|Mouse|Key)(?:Down|Up|Press)?)$/.test(s) && (e[s] = [
        (t)=>{
            var l;
            return (l = t == null ? void 0 : t.preventDefault) == null ? void 0 : l.call(t);
        }
    ]);
    for(let s in e)Object.assign(r, {
        [s] (t, ...l) {
            let i = e[s];
            for (let o of i){
                if ((t instanceof Event || (t == null ? void 0 : t.nativeEvent) instanceof Event) && t.defaultPrevented) return;
                o(t, ...l);
            }
        }
    });
    return r;
}
function V(...n) {
    var a;
    if (n.length === 0) return {};
    if (n.length === 1) return n[0];
    let r = {}, e = {};
    for (let s of n)for(let t in s)t.startsWith("on") && typeof s[t] == "function" ? ((a = e[t]) != null || (e[t] = []), e[t].push(s[t])) : r[t] = s[t];
    for(let s in e)Object.assign(r, {
        [s] (...t) {
            let l = e[s];
            for (let i of l)i == null || i(...t);
        }
    });
    return r;
}
function Y(n) {
    var r;
    return Object.assign((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(n), {
        displayName: (r = n.displayName) != null ? r : n.name
    });
}
function m(n) {
    let r = Object.assign({}, n);
    for(let e in r)r[e] === void 0 && delete r[e];
    return r;
}
function h(n, r = []) {
    let e = Object.assign({}, n);
    for (let a of r)a in e && delete e[a];
    return e;
}
function H(n) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].version.split(".")[0] >= "19" ? n.props.ref : n.ref;
}
function b(n) {
    return n === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"] || n === Symbol.for("react.fragment");
}
function D(n) {
    return b(n.type);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/internal/disabled.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DisabledProvider",
    ()=>l,
    "useDisabled",
    ()=>a
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(void 0);
function a() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(e);
}
function l({ value: t, children: o }) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(e.Provider, {
        value: t
    }, o);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/components/description/description.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Description",
    ()=>M,
    "useDescribedBy",
    ()=>w,
    "useDescriptions",
    ()=>H
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-slot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-sync-refs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$disabled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/internal/disabled.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/render.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
let a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
a.displayName = "DescriptionContext";
function f() {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(a);
    if (r === null) {
        let e = new Error("You used a <Description /> component, but it is not inside a relevant parent.");
        throw Error.captureStackTrace && Error.captureStackTrace(e, f), e;
    }
    return r;
}
function w() {
    var r, e;
    return (e = (r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(a)) == null ? void 0 : r.value) != null ? e : void 0;
}
function H() {
    let [r, e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    return [
        r.length > 0 ? r.join(" ") : void 0,
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>function(t) {
                let i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((n)=>(e((o)=>[
                            ...o,
                            n
                        ]), ()=>e((o)=>{
                            let s = o.slice(), p = s.indexOf(n);
                            return p !== -1 && s.splice(p, 1), s;
                        }))), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
                        register: i,
                        slot: t.slot,
                        name: t.name,
                        props: t.props,
                        value: t.value
                    }), [
                    i,
                    t.slot,
                    t.name,
                    t.props,
                    t.value
                ]);
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(a.Provider, {
                    value: l
                }, t.children);
            }, [
            e
        ])
    ];
}
let I = "p";
function C(r, e) {
    let c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$disabled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisabled"])(), { id: i = `headlessui-description-${c}`, ...l } = r, n = f(), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(e);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>n.register(i), [
        i,
        n.register
    ]);
    let s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlot"])({
        ...n.slot,
        disabled: t || !1
    }), p = {
        ref: o,
        ...n.props,
        id: i
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])()({
        ourProps: p,
        theirProps: l,
        slot: s,
        defaultTag: I,
        name: n.name || "Description"
    });
}
let _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(C), M = Object.assign(_, {});
;
}),
"[project]/node_modules/@headlessui/react/dist/components/keyboard.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Keys",
    ()=>o
]);
var o = ((r)=>(r.Space = " ", r.Enter = "Enter", r.Escape = "Escape", r.Backspace = "Backspace", r.Delete = "Delete", r.ArrowLeft = "ArrowLeft", r.ArrowUp = "ArrowUp", r.ArrowRight = "ArrowRight", r.ArrowDown = "ArrowDown", r.Home = "Home", r.End = "End", r.PageUp = "PageUp", r.PageDown = "PageDown", r.Tab = "Tab", r))(o || {});
;
}),
"[project]/node_modules/@headlessui/react/dist/internal/id.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IdProvider",
    ()=>f,
    "useProvidedId",
    ()=>u
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(void 0);
function u() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(e);
}
function f({ id: t, children: r }) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(e.Provider, {
        value: t
    }, r);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/components/label/label.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Label",
    ()=>Z,
    "useLabelContext",
    ()=>C,
    "useLabelledBy",
    ()=>N,
    "useLabels",
    ()=>V
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-slot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-sync-refs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$disabled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/internal/disabled.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$id$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/internal/id.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/render.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
let L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
L.displayName = "LabelContext";
function C() {
    let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(L);
    if (n === null) {
        let l = new Error("You used a <Label /> component, but it is not inside a relevant parent.");
        throw Error.captureStackTrace && Error.captureStackTrace(l, C), l;
    }
    return n;
}
function N(n) {
    var a, e, o;
    let l = (e = (a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(L)) == null ? void 0 : a.value) != null ? e : void 0;
    return ((o = n == null ? void 0 : n.length) != null ? o : 0) > 0 ? [
        l,
        ...n
    ].filter(Boolean).join(" ") : l;
}
function V({ inherit: n = !1 } = {}) {
    let l = N(), [a, e] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]), o = n ? [
        l,
        ...a
    ].filter(Boolean) : a;
    return [
        o.length > 0 ? o.join(" ") : void 0,
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>function(t) {
                let p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((i)=>(e((u)=>[
                            ...u,
                            i
                        ]), ()=>e((u)=>{
                            let d = u.slice(), f = d.indexOf(i);
                            return f !== -1 && d.splice(f, 1), d;
                        }))), b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
                        register: p,
                        slot: t.slot,
                        name: t.name,
                        props: t.props,
                        value: t.value
                    }), [
                    p,
                    t.slot,
                    t.name,
                    t.props,
                    t.value
                ]);
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(L.Provider, {
                    value: b
                }, t.children);
            }, [
            e
        ])
    ];
}
let G = "label";
function U(n, l) {
    var y;
    let a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), e = C(), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$id$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProvidedId"])(), T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$disabled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisabled"])(), { id: t = `headlessui-label-${a}`, htmlFor: p = o != null ? o : (y = e.props) == null ? void 0 : y.htmlFor, passive: b = !1, ...i } = n, u = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(l);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>e.register(t), [
        t,
        e.register
    ]);
    let d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((s)=>{
        let g = s.currentTarget;
        if (!(s.target !== s.currentTarget && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInteractiveElement"](s.target)) && (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLLabelElement"](g) && s.preventDefault(), e.props && "onClick" in e.props && typeof e.props.onClick == "function" && e.props.onClick(s), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLLabelElement"](g))) {
            let r = document.getElementById(g.htmlFor);
            if (r) {
                let E = r.getAttribute("disabled");
                if (E === "true" || E === "") return;
                let x = r.getAttribute("aria-disabled");
                if (x === "true" || x === "") return;
                (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLInputElement"](r) && (r.type === "file" || r.type === "radio" || r.type === "checkbox") || r.role === "radio" || r.role === "checkbox" || r.role === "switch") && r.click(), r.focus({
                    preventScroll: !0
                });
            }
        }
    }), f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlot"])({
        ...e.slot,
        disabled: T || !1
    }), c = {
        ref: u,
        ...e.props,
        id: t,
        htmlFor: p,
        onClick: d
    };
    return b && ("onClick" in c && (delete c.htmlFor, delete c.onClick), "onClick" in i && delete i.onClick), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])()({
        ourProps: c,
        theirProps: i,
        slot: f,
        defaultTag: p ? G : "div",
        name: e.name || "Label"
    });
}
let j = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(U), Z = Object.assign(j, {});
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-on-unmount.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useOnUnmount",
    ()=>c
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$micro$2d$task$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/micro-task.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
;
;
;
function c(t) {
    let r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(t), e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>(e.current = !1, ()=>{
            e.current = !0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$micro$2d$task$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["microTask"])(()=>{
                e.current && r();
            });
        }), [
        r
    ]);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/internal/portal-force-root.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ForcePortalRoot",
    ()=>l,
    "usePortalRoot",
    ()=>a
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(!1);
function a() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(e);
}
function l(o) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(e.Provider, {
        value: o.force
    }, o.children);
}
;
}),
"[project]/node_modules/@headlessui/react/dist/components/portal/portal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Portal",
    ()=>te,
    "PortalGroup",
    ()=>X,
    "useNestedPortals",
    ()=>ee
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$on$2d$unmount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-on-unmount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-owner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-sync-refs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$portal$2d$force$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/internal/portal-force-root.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/env.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/render.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
function W(e) {
    let o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$portal$2d$force$2d$root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePortalRoot"])(), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(c), [r, p] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(()=>{
        var s;
        if (!o && l !== null) return (s = l.current) != null ? s : null;
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].isServer) return null;
        let t = e == null ? void 0 : e.getElementById("headlessui-portal-root");
        if (t) return t;
        if (e === null) return null;
        let n = e.createElement("div");
        return n.setAttribute("id", "headlessui-portal-root"), e.body.appendChild(n);
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        r !== null && (e != null && e.body.contains(r) || e == null || e.body.appendChild(r));
    }, [
        r,
        e
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        o || l !== null && p(l.current);
    }, [
        l,
        p,
        o
    ]), r;
}
let _ = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], j = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(function(o, l) {
    let { ownerDocument: r = null, ...p } = o, t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionalRef"])((a)=>{
        t.current = a;
    }), l), s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOwnerDocument"])(t.current), C = r != null ? r : s, u = W(C), y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(m), g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisposables"])(), v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$on$2d$unmount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnUnmount"])(()=>{
        var a;
        u && u.childNodes.length <= 0 && ((a = u.parentElement) == null || a.removeChild(u));
    }), u ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        "data-headlessui-portal": "",
        ref: (a)=>{
            g.dispose(), y && a && g.add(y.register(a));
        }
    }, v({
        ourProps: {
            ref: n
        },
        theirProps: p,
        slot: {},
        defaultTag: _,
        name: "Portal"
    })), u) : null;
});
function S(e, o) {
    let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(o), { enabled: r = !0, ownerDocument: p, ...t } = e, n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])();
    return r ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(j, {
        ...t,
        ownerDocument: p,
        ref: l
    }) : n({
        ourProps: {
            ref: l
        },
        theirProps: t,
        slot: {},
        defaultTag: _,
        name: "Portal"
    });
}
let I = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function D(e, o) {
    let { target: l, ...r } = e, t = {
        ref: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(o)
    }, n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(c.Provider, {
        value: l
    }, n({
        ourProps: t,
        theirProps: r,
        defaultTag: I,
        name: "Popover.Group"
    }));
}
let m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function ee() {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(m), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((t)=>(o.current.push(t), e && e.register(t), ()=>r(t))), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((t)=>{
        let n = o.current.indexOf(t);
        n !== -1 && o.current.splice(n, 1), e && e.unregister(t);
    }), p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            register: l,
            unregister: r,
            portals: o
        }), [
        l,
        r,
        o
    ]);
    return [
        o,
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>function({ children: n }) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(m.Provider, {
                    value: p
                }, n);
            }, [
            p
        ])
    ];
}
let J = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(S), X = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(D), te = Object.assign(J, {
    Group: X
});
;
}),
"[project]/node_modules/@headlessui/react/dist/utils/element-movement.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ElementPositionState",
    ()=>c,
    "computeVisualPosition",
    ()=>a,
    "detectMovement",
    ()=>p
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
;
const c = {
    Idle: {
        kind: "Idle"
    },
    Tracked: (e)=>({
            kind: "Tracked",
            position: e
        }),
    Moved: {
        kind: "Moved"
    }
};
function a(e) {
    let t = e.getBoundingClientRect();
    return `${t.x},${t.y}`;
}
function p(e, t, i) {
    let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])();
    if (t.kind === "Tracked") {
        let o = function() {
            d !== a(e) && (n.dispose(), i());
        };
        var f = o;
        let { position: d } = t, s = new ResizeObserver(o);
        s.observe(e), n.add(()=>s.disconnect()), n.addEventListener(window, "scroll", o, {
            passive: !0
        }), n.addEventListener(window, "resize", o);
    }
    return ()=>n.dispose();
}
;
}),
"[project]/node_modules/@headlessui/react/dist/components/menu/menu-machine.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ActionTypes",
    ()=>C,
    "ActivationTrigger",
    ()=>D,
    "MenuMachine",
    ()=>h,
    "MenuState",
    ()=>P
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/machine.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machines$2f$stack$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/machines/stack-machine.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/calculate-active-index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$element$2d$movement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/element-movement.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/focus-management.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/match.js [app-client] (ecmascript)");
var y = Object.defineProperty;
var M = (e, i, t)=>i in e ? y(e, i, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[i] = t;
var S = (e, i, t)=>(M(e, typeof i != "symbol" ? i + "" : i, t), t);
;
;
;
;
;
;
var P = ((t)=>(t[t.Open = 0] = "Open", t[t.Closed = 1] = "Closed", t))(P || {}), D = ((t)=>(t[t.Pointer = 0] = "Pointer", t[t.Other = 1] = "Other", t))(D || {}), C = ((o)=>(o[o.OpenMenu = 0] = "OpenMenu", o[o.CloseMenu = 1] = "CloseMenu", o[o.GoToItem = 2] = "GoToItem", o[o.Search = 3] = "Search", o[o.ClearSearch = 4] = "ClearSearch", o[o.RegisterItems = 5] = "RegisterItems", o[o.UnregisterItems = 6] = "UnregisterItems", o[o.SetButtonElement = 7] = "SetButtonElement", o[o.SetItemsElement = 8] = "SetItemsElement", o[o.SortItems = 9] = "SortItems", o[o.MarkButtonAsMoved = 10] = "MarkButtonAsMoved", o))(C || {});
function x(e, i = (t)=>t) {
    let t = e.activeItemIndex !== null ? e.items[e.activeItemIndex] : null, n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortByDomNode"])(i(e.items.slice()), (s)=>s.dataRef.current.domRef.current), r = t ? n.indexOf(t) : null;
    return r === -1 && (r = null), {
        items: n,
        activeItemIndex: r
    };
}
let k = {
    [1] (e) {
        if (e.menuState === 1) return e;
        let i = e.buttonElement ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$element$2d$movement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementPositionState"].Tracked((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$element$2d$movement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeVisualPosition"])(e.buttonElement)) : e.buttonPositionState;
        return {
            ...e,
            activeItemIndex: null,
            pendingFocus: {
                focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Nothing
            },
            menuState: 1,
            buttonPositionState: i
        };
    },
    [0] (e, i) {
        return e.menuState === 0 ? e : {
            ...e,
            __demoMode: !1,
            pendingFocus: i.focus,
            menuState: 0,
            buttonPositionState: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$element$2d$movement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementPositionState"].Idle
        };
    },
    [2]: (e, i)=>{
        var s, l, a, I, f;
        if (e.menuState === 1) return e;
        let t = {
            ...e,
            searchQuery: "",
            activationTrigger: (s = i.trigger) != null ? s : 1,
            __demoMode: !1
        };
        if (i.focus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Nothing) return {
            ...t,
            activeItemIndex: null
        };
        if (i.focus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Specific) return {
            ...t,
            activeItemIndex: e.items.findIndex((d)=>d.id === i.id)
        };
        if (i.focus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Previous) {
            let d = e.activeItemIndex;
            if (d !== null) {
                let o = e.items[d].dataRef.current.domRef, c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateActiveIndex"])(i, {
                    resolveItems: ()=>e.items,
                    resolveActiveIndex: ()=>e.activeItemIndex,
                    resolveId: (u)=>u.id,
                    resolveDisabled: (u)=>u.dataRef.current.disabled
                });
                if (c !== null) {
                    let u = e.items[c].dataRef.current.domRef;
                    if (((l = o.current) == null ? void 0 : l.previousElementSibling) === u.current || ((a = u.current) == null ? void 0 : a.previousElementSibling) === null) return {
                        ...t,
                        activeItemIndex: c
                    };
                }
            }
        } else if (i.focus === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Next) {
            let d = e.activeItemIndex;
            if (d !== null) {
                let o = e.items[d].dataRef.current.domRef, c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateActiveIndex"])(i, {
                    resolveItems: ()=>e.items,
                    resolveActiveIndex: ()=>e.activeItemIndex,
                    resolveId: (u)=>u.id,
                    resolveDisabled: (u)=>u.dataRef.current.disabled
                });
                if (c !== null) {
                    let u = e.items[c].dataRef.current.domRef;
                    if (((I = o.current) == null ? void 0 : I.nextElementSibling) === u.current || ((f = u.current) == null ? void 0 : f.nextElementSibling) === null) return {
                        ...t,
                        activeItemIndex: c
                    };
                }
            }
        }
        let n = x(e), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateActiveIndex"])(i, {
            resolveItems: ()=>n.items,
            resolveActiveIndex: ()=>n.activeItemIndex,
            resolveId: (d)=>d.id,
            resolveDisabled: (d)=>d.dataRef.current.disabled
        });
        return {
            ...t,
            ...n,
            activeItemIndex: r
        };
    },
    [3]: (e, i)=>{
        let n = e.searchQuery !== "" ? 0 : 1, r = e.searchQuery + i.value.toLowerCase(), l = (e.activeItemIndex !== null ? e.items.slice(e.activeItemIndex + n).concat(e.items.slice(0, e.activeItemIndex + n)) : e.items).find((I)=>{
            var f;
            return ((f = I.dataRef.current.textValue) == null ? void 0 : f.startsWith(r)) && !I.dataRef.current.disabled;
        }), a = l ? e.items.indexOf(l) : -1;
        return a === -1 || a === e.activeItemIndex ? {
            ...e,
            searchQuery: r
        } : {
            ...e,
            searchQuery: r,
            activeItemIndex: a,
            activationTrigger: 1
        };
    },
    [4] (e) {
        return e.searchQuery === "" ? e : {
            ...e,
            searchQuery: "",
            searchActiveItemIndex: null
        };
    },
    [5]: (e, i)=>{
        let t = e.items.concat(i.items.map((r)=>r)), n = e.activeItemIndex;
        return e.pendingFocus.focus !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Nothing && (n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateActiveIndex"])(e.pendingFocus, {
            resolveItems: ()=>t,
            resolveActiveIndex: ()=>e.activeItemIndex,
            resolveId: (r)=>r.id,
            resolveDisabled: (r)=>r.dataRef.current.disabled
        })), {
            ...e,
            items: t,
            activeItemIndex: n,
            pendingFocus: {
                focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Nothing
            },
            pendingShouldSort: !0
        };
    },
    [6]: (e, i)=>{
        let t = e.items, n = [], r = new Set(i.items);
        for (let [s, l] of t.entries())if (r.has(l.id) && (n.push(s), r.delete(l.id), r.size === 0)) break;
        if (n.length > 0) {
            t = t.slice();
            for (let s of n.reverse())t.splice(s, 1);
        }
        return {
            ...e,
            items: t,
            activationTrigger: 1
        };
    },
    [7]: (e, i)=>e.buttonElement === i.element ? e : {
            ...e,
            buttonElement: i.element
        },
    [8]: (e, i)=>e.itemsElement === i.element ? e : {
            ...e,
            itemsElement: i.element
        },
    [9]: (e)=>e.pendingShouldSort ? {
            ...e,
            ...x(e),
            pendingShouldSort: !1
        } : e,
    [10] (e) {
        return e.buttonPositionState.kind !== "Tracked" ? e : {
            ...e,
            buttonPositionState: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$element$2d$movement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementPositionState"].Moved
        };
    }
};
class h extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Machine"] {
    constructor(t){
        super(t);
        S(this, "actions", {
            registerItem: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["batch"])(()=>{
                let t = [], n = new Set;
                return [
                    (r, s)=>{
                        n.has(s) || (n.add(s), t.push({
                            id: r,
                            dataRef: s
                        }));
                    },
                    ()=>(n.clear(), this.send({
                            type: 5,
                            items: t.splice(0)
                        }))
                ];
            }),
            unregisterItem: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["batch"])(()=>{
                let t = [];
                return [
                    (n)=>t.push(n),
                    ()=>this.send({
                            type: 6,
                            items: t.splice(0)
                        })
                ];
            })
        });
        S(this, "selectors", {
            activeDescendantId (t) {
                var s;
                let n = t.activeItemIndex, r = t.items;
                return n === null || (s = r[n]) == null ? void 0 : s.id;
            },
            isActive (t, n) {
                var l;
                let r = t.activeItemIndex, s = t.items;
                return r !== null ? ((l = s[r]) == null ? void 0 : l.id) === n : !1;
            },
            shouldScrollIntoView (t, n) {
                return t.__demoMode || t.menuState !== 0 || t.activationTrigger === 0 ? !1 : this.isActive(t, n);
            },
            didButtonMove (t) {
                return t.buttonPositionState.kind === "Moved";
            }
        });
        this.on(5, ()=>{
            this.disposables.requestAnimationFrame(()=>{
                this.send({
                    type: 9
                });
            });
        });
        {
            let n = this.state.id, r = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machines$2f$stack$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stackMachines"].get(null);
            this.disposables.add(r.on(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machines$2f$stack$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].Push, (s)=>{
                !r.selectors.isTop(s, n) && this.state.menuState === 0 && this.send({
                    type: 1
                });
            })), this.on(0, ()=>r.actions.push(n)), this.on(1, ()=>r.actions.pop(n));
        }
        this.disposables.group((n)=>{
            this.on(1, (r)=>{
                r.buttonElement && (n.dispose(), n.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$element$2d$movement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["detectMovement"])(r.buttonElement, r.buttonPositionState, ()=>{
                    this.send({
                        type: 10
                    });
                })));
            });
        });
    }
    static new({ id: t, __demoMode: n = !1 }) {
        return new h({
            id: t,
            __demoMode: n,
            menuState: n ? 0 : 1,
            buttonElement: null,
            itemsElement: null,
            items: [],
            searchQuery: "",
            activeItemIndex: null,
            activationTrigger: 1,
            pendingShouldSort: !1,
            pendingFocus: {
                focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Nothing
            },
            buttonPositionState: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$element$2d$movement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ElementPositionState"].Idle
        });
    }
    reduce(t, n) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(n.type, k, t, n);
    }
}
;
}),
"[project]/node_modules/@headlessui/react/dist/components/menu/menu-machine-glue.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuContext",
    ()=>a,
    "useMenuMachine",
    ()=>s,
    "useMenuMachineContext",
    ()=>p
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$on$2d$unmount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-on-unmount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/menu/menu-machine.js [app-client] (ecmascript)");
;
;
;
const a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function p(t) {
    let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(a);
    if (n === null) {
        let e = new Error(`<${t} /> is missing a parent <Menu /> component.`);
        throw Error.captureStackTrace && Error.captureStackTrace(e, s), e;
    }
    return n;
}
function s({ id: t, __demoMode: n = !1 }) {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuMachine"].new({
            id: t,
            __demoMode: n
        }), []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$on$2d$unmount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnUnmount"])(()=>e.dispose()), e;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/components/menu/menu.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Menu",
    ()=>lo,
    "MenuButton",
    ()=>ft,
    "MenuHeading",
    ()=>Et,
    "MenuItem",
    ()=>gt,
    "MenuItems",
    ()=>yt,
    "MenuSection",
    ()=>Pt,
    "MenuSeparator",
    ()=>Mt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$aria$2f$focus$2f$dist$2f$useFocusRing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-aria/focus/dist/useFocusRing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$aria$2f$interactions$2f$dist$2f$useHover$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-aria/interactions/dist/useHover.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$active$2d$press$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-active-press.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$element$2d$size$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-element-size.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$handle$2d$toggle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-handle-toggle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$inert$2d$others$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-inert-others.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$on$2d$disappear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-on-disappear.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$outside$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-outside-click.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-owner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$quick$2d$release$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-quick-release.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$resolve$2d$button$2d$type$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-resolve-button-type.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$scroll$2d$lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-scroll-lock.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-slot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-sync-refs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$text$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-text-value.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$tracked$2d$pointer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-tracked-pointer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-transition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$tree$2d$walker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-tree-walker.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/internal/floating.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/internal/open-closed.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machines$2f$stack$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/machines/stack-machine.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/react-glue.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/calculate-active-index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/dom.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/focus-management.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/match.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/owner.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/render.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$description$2f$description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/description/description.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/keyboard.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$label$2f$label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/label/label.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$portal$2f$portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/portal/portal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/menu/menu-machine.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/components/menu/menu-machine-glue.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
let Ze = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"];
function et(m, y) {
    let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), { __demoMode: a = !1, ...p } = m, s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuMachine"])({
        id: l,
        __demoMode: a
    }), [n, M, f] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(s, (d)=>[
            d.menuState,
            d.itemsElement,
            d.buttonElement
        ]), _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(y), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$machines$2f$stack$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stackMachines"].get(null), F = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(o, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((d)=>o.selectors.isTop(d, l), [
        o,
        l
    ]));
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$outside$2d$click$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOutsideClick"])(F, [
        f,
        M
    ], (d, T)=>{
        var P;
        s.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFocusableElement"])(T, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FocusableMode"].Loose) || (d.preventDefault(), (P = s.state.buttonElement) == null || P.focus());
    });
    let I = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(()=>{
        s.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
        });
    }), b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlot"])({
        open: n === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open,
        close: I
    }), i = {
        ref: _
    }, g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloatingProvider"], null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuContext"].Provider, {
        value: s
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OpenClosedProvider"], {
        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(n, {
            [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open]: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Open,
            [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Closed]: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Closed
        })
    }, g({
        ourProps: i,
        theirProps: p,
        slot: b,
        defaultTag: Ze,
        name: "Menu"
    }))));
}
let tt = "button";
function ot(m, y) {
    let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuMachineContext"])("Menu.Button"), a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), { id: p = `headlessui-menu-button-${a}`, disabled: s = !1, autoFocus: n = !1, ...M } = m, f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFloatingReferenceProps"])(), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(y, f, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFloatingReference"])(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((t)=>l.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].SetButtonElement,
            element: t
        }))), F = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((t)=>{
        switch(t.key){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].Space:
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].Enter:
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].ArrowDown:
                t.preventDefault(), t.stopPropagation(), l.send({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].OpenMenu,
                    focus: {
                        focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].First
                    }
                });
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].ArrowUp:
                t.preventDefault(), t.stopPropagation(), l.send({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].OpenMenu,
                    focus: {
                        focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Last
                    }
                });
                break;
        }
    }), I = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((t)=>{
        switch(t.key){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].Space:
                t.preventDefault();
                break;
        }
    }), [b, i, g] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(l, (t)=>[
            t.menuState,
            t.buttonElement,
            t.itemsElement
        ]), d = b === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$quick$2d$release$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuickRelease"])(d, {
        trigger: i,
        action: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((t)=>{
            if (i != null && i.contains(t.target)) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$quick$2d$release$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"].Ignore;
            let S = t.target.closest('[role="menuitem"]:not([data-disabled])');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$dom$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"](S) ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$quick$2d$release$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"].Select(S) : g != null && g.contains(t.target) ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$quick$2d$release$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"].Ignore : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$quick$2d$release$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"].Close;
        }, [
            i,
            g
        ]),
        close: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>l.send({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
            }), []),
        select: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])((t)=>t.click(), [])
    });
    let T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$handle$2d$toggle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useHandleToggle"])((t)=>{
        var S;
        s || (b === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open ? ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"])(()=>l.send({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
            })), (S = f.current) == null || S.focus({
            preventScroll: !0
        })) : (t.preventDefault(), l.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].OpenMenu,
            focus: {
                focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Nothing
            },
            trigger: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActivationTrigger"].Pointer
        })));
    }), { isFocusVisible: P, focusProps: L } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$aria$2f$focus$2f$dist$2f$useFocusRing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFocusRing"])({
        autoFocus: n
    }), { isHovered: O, hoverProps: v } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$aria$2f$interactions$2f$dist$2f$useHover$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useHover"])({
        isDisabled: s
    }), { pressed: D, pressProps: U } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$active$2d$press$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActivePress"])({
        disabled: s
    }), H = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlot"])({
        open: b === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open,
        active: D || b === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open,
        disabled: s,
        hover: O,
        focus: P,
        autofocus: n
    }), G = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(_(), {
        ref: o,
        id: p,
        type: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$resolve$2d$button$2d$type$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useResolveButtonType"])(m, f.current),
        "aria-haspopup": "menu",
        "aria-controls": g == null ? void 0 : g.id,
        "aria-expanded": b === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open,
        disabled: s || void 0,
        autoFocus: n,
        onKeyDown: F,
        onKeyUp: I
    }, T, L, v, U);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])()({
        ourProps: G,
        theirProps: M,
        slot: H,
        defaultTag: tt,
        name: "Menu.Button"
    });
}
let nt = "div", rt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderFeatures"].RenderStrategy | __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderFeatures"].Static;
function at(m, y) {
    let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), { id: a = `headlessui-menu-items-${l}`, anchor: p, portal: s = !1, modal: n = !0, transition: M = !1, ...f } = m, _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useResolvedAnchor"])(p), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuMachineContext"])("Menu.Items"), [F, I] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFloatingPanel"])(_), b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$floating$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFloatingPanelProps"])(), [i, g] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(y, _ ? F : null, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((e)=>o.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].SetItemsElement,
            element: e
        })), g), [T, P] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(o, (e)=>[
            e.menuState,
            e.buttonElement
        ]), L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOwnerDocument"])(P), O = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOwnerDocument"])(i);
    _ && (s = !0);
    let v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenClosed"])(), [D, U] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])(M, i, v !== null ? (v & __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Open) === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Open : T === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$on$2d$disappear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOnDisappear"])(D, P, ()=>{
        o.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
        });
    });
    let H = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(o, (e)=>e.__demoMode), G = H ? !1 : n && T === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$scroll$2d$lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollLock"])(G, O);
    let w = H ? !1 : n && T === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$inert$2d$others$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInertOthers"])(w, {
        allowed: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(()=>[
                P,
                i
            ], [
            P,
            i
        ])
    });
    let S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(o, o.selectors.didButtonMove) ? !1 : D;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let e = i;
        e && T === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$owner$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isActiveElement"])(e) || e.focus({
            preventScroll: !0
        }));
    }, [
        T,
        i
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$tree$2d$walker$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTreeWalker"])(T === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open, {
        container: i,
        accept (e) {
            return e.getAttribute("role") === "menuitem" ? NodeFilter.FILTER_REJECT : e.hasAttribute("role") ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT;
        },
        walk (e) {
            e.setAttribute("role", "none");
        }
    });
    let z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisposables"])(), le = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((e)=>{
        var N, Y, Z;
        switch(z.dispose(), e.key){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].Space:
                if (o.state.searchQuery !== "") return e.preventDefault(), e.stopPropagation(), o.send({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].Search,
                    value: e.key
                });
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].Enter:
                if (e.preventDefault(), e.stopPropagation(), o.state.activeItemIndex !== null) {
                    let { dataRef: de } = o.state.items[o.state.activeItemIndex];
                    (Y = (N = de.current) == null ? void 0 : N.domRef.current) == null || Y.click();
                }
                o.send({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
                }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["restoreFocusIfNecessary"])(o.state.buttonElement);
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].ArrowDown:
                return e.preventDefault(), e.stopPropagation(), o.send({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].GoToItem,
                    focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Next
                });
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].ArrowUp:
                return e.preventDefault(), e.stopPropagation(), o.send({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].GoToItem,
                    focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Previous
                });
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].Home:
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].PageUp:
                return e.preventDefault(), e.stopPropagation(), o.send({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].GoToItem,
                    focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].First
                });
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].End:
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].PageDown:
                return e.preventDefault(), e.stopPropagation(), o.send({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].GoToItem,
                    focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Last
                });
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].Escape:
                e.preventDefault(), e.stopPropagation(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"])(()=>o.send({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
                    })), (Z = o.state.buttonElement) == null || Z.focus({
                    preventScroll: !0
                });
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].Tab:
                e.preventDefault(), e.stopPropagation(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"])(()=>o.send({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
                    })), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focusFrom"])(o.state.buttonElement, e.shiftKey ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Previous : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Next);
                break;
            default:
                e.key.length === 1 && (o.send({
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].Search,
                    value: e.key
                }), z.setTimeout(()=>o.send({
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].ClearSearch
                    }), 350));
                break;
        }
    }), pe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((e)=>{
        switch(e.key){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$keyboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Keys"].Space:
                e.preventDefault();
                break;
        }
    }), ie = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlot"])({
        open: T === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open
    }), ue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(_ ? b() : {}, {
        "aria-activedescendant": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(o, o.selectors.activeDescendantId),
        "aria-labelledby": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(o, (e)=>{
            var N;
            return (N = e.buttonElement) == null ? void 0 : N.id;
        }),
        id: a,
        onKeyDown: le,
        onKeyUp: pe,
        role: "menu",
        tabIndex: T === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuState"].Open ? 0 : void 0,
        ref: d,
        style: {
            ...f.style,
            ...I,
            "--button-width": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$element$2d$size$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useElementSize"])(D, P, !0).width
        },
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transitionDataAttributes"])(U)
    }), me = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$portal$2f$portal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        enabled: s ? m.static || D : !1,
        ownerDocument: L
    }, me({
        ourProps: ue,
        theirProps: f,
        slot: ie,
        defaultTag: nt,
        features: rt,
        visible: S,
        name: "Menu.Items"
    }));
}
let st = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"];
function lt(m, y) {
    let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), { id: a = `headlessui-menu-item-${l}`, disabled: p = !1, ...s } = m, n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuMachineContext"])("Menu.Item"), M = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(n, (t)=>n.selectors.isActive(t, a)), f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), _ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(y, f), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$react$2d$glue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlice"])(n, (t)=>n.selectors.shouldScrollIntoView(t, a));
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        if (o) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["disposables"])().requestAnimationFrame(()=>{
            var t, S;
            (S = (t = f.current) == null ? void 0 : t.scrollIntoView) == null || S.call(t, {
                block: "nearest"
            });
        });
    }, [
        o,
        f
    ]);
    let F = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$text$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTextValue"])(f), I = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        disabled: p,
        domRef: f,
        get textValue () {
            return F();
        }
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        I.current.disabled = p;
    }, [
        I,
        p
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>(n.actions.registerItem(a, I), ()=>n.actions.unregisterItem(a)), [
        I,
        a
    ]);
    let b = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(()=>{
        n.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
        });
    }), i = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((t)=>{
        if (p) return t.preventDefault();
        n.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].CloseMenu
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$focus$2d$management$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["restoreFocusIfNecessary"])(n.state.buttonElement);
    }), g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(()=>{
        if (p) return n.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].GoToItem,
            focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Nothing
        });
        n.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].GoToItem,
            focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Specific,
            id: a
        });
    }), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$tracked$2d$pointer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTrackedPointer"])(), T = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((t)=>d.update(t)), P = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((t)=>{
        d.wasMoved(t) && (p || M || n.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].GoToItem,
            focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Specific,
            id: a,
            trigger: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActivationTrigger"].Pointer
        }));
    }), L = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((t)=>{
        d.wasMoved(t) && (p || M && n.state.activationTrigger === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActivationTrigger"].Pointer && n.send({
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$menu$2f$menu$2d$machine$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActionTypes"].GoToItem,
            focus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$calculate$2d$active$2d$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Focus"].Nothing
        }));
    }), [O, v] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$label$2f$label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabels"])(), [D, U] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$description$2f$description$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDescriptions"])(), H = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSlot"])({
        active: M,
        focus: M,
        disabled: p,
        close: b
    }), G = {
        id: a,
        ref: _,
        role: "menuitem",
        tabIndex: p === !0 ? void 0 : -1,
        "aria-disabled": p === !0 ? !0 : void 0,
        "aria-labelledby": O,
        "aria-describedby": D,
        disabled: void 0,
        onClick: i,
        onFocus: g,
        onPointerEnter: T,
        onMouseEnter: T,
        onPointerMove: P,
        onMouseMove: P,
        onPointerLeave: L,
        onMouseLeave: L
    }, w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(v, null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(U, null, w({
        ourProps: G,
        theirProps: s,
        slot: H,
        defaultTag: st,
        name: "Menu.Item"
    })));
}
let pt = "div";
function it(m, y) {
    let [l, a] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$label$2f$label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabels"])(), p = m, s = {
        ref: y,
        "aria-labelledby": l,
        role: "group"
    }, n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(a, null, n({
        ourProps: s,
        theirProps: p,
        slot: {},
        defaultTag: pt,
        name: "Menu.Section"
    }));
}
let ut = "header";
function mt(m, y) {
    let l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), { id: a = `headlessui-menu-heading-${l}`, ...p } = m, s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$components$2f$label$2f$label$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLabelContext"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>s.register(a), [
        a,
        s.register
    ]);
    let n = {
        id: a,
        ref: y,
        role: "presentation",
        ...s.props
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])()({
        ourProps: n,
        theirProps: p,
        slot: {},
        defaultTag: ut,
        name: "Menu.Heading"
    });
}
let dt = "div";
function Tt(m, y) {
    let l = m, a = {
        ref: y,
        role: "separator"
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])()({
        ourProps: a,
        theirProps: l,
        slot: {},
        defaultTag: dt,
        name: "Menu.Separator"
    });
}
let ct = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(et), ft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(ot), yt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(at), gt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(lt), Pt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(it), Et = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(mt), Mt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(Tt), lo = Object.assign(ct, {
    Button: ft,
    Items: yt,
    Item: gt,
    Section: Pt,
    Heading: Et,
    Separator: Mt
});
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-is-mounted.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useIsMounted",
    ()=>f
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
;
;
function f() {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>(e.current = !0, ()=>{
            e.current = !1;
        }), []), e;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/hooks/use-server-handoff-complete.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useServerHandoffComplete",
    ()=>l
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/env.js [app-client] (ecmascript)");
;
;
function s() {
    let r = typeof document == "undefined";
    return "useSyncExternalStore" in __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ ? ((o)=>o.useSyncExternalStore)(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__)(()=>()=>{}, ()=>!1, ()=>!r) : !1;
}
function l() {
    let r = s(), [e, n] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useState(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].isHandoffComplete);
    return e && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].isHandoffComplete === !1 && n(!1), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useEffect({
        "l.useEffect": ()=>{
            e !== !0 && n(!0);
        }
    }["l.useEffect"], [
        e
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useEffect({
        "l.useEffect": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$env$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["env"].handoff()
    }["l.useEffect"], []), r ? !1 : e;
}
;
}),
"[project]/node_modules/@headlessui/react/dist/components/transition/transition.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Transition",
    ()=>Ke,
    "TransitionChild",
    ()=>Oe
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-disposables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-event.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$is$2d$mounted$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-is-mounted.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-iso-morphic-effect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-latest-value.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$server$2d$handoff$2d$complete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-server-handoff-complete.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-sync-refs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/hooks/use-transition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/internal/open-closed.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$class$2d$names$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/class-names.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/match.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@headlessui/react/dist/utils/render.js [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
function ue(e) {
    var t;
    return !!(e.enter || e.enterFrom || e.enterTo || e.leave || e.leaveFrom || e.leaveTo) || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFragment"])((t = e.as) != null ? t : de) || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Children.count(e.children) === 1;
}
let V = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
V.displayName = "TransitionContext";
var De = ((n)=>(n.Visible = "visible", n.Hidden = "hidden", n))(De || {});
function He() {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(V);
    if (e === null) throw new Error("A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />.");
    return e;
}
function Ae() {
    let e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(w);
    if (e === null) throw new Error("A <Transition.Child /> is used but it is missing a parent <Transition /> or <Transition.Root />.");
    return e;
}
let w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
w.displayName = "NestingContext";
function M(e) {
    return "children" in e ? M(e.children) : e.current.filter(({ el: t })=>t.current !== null).filter(({ state: t })=>t === "visible").length > 0;
}
function Te(e, t) {
    let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$latest$2d$value$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLatestValue"])(e), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]), S = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$is$2d$mounted$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsMounted"])(), R = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$disposables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisposables"])(), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((o, i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderStrategy"].Hidden)=>{
        let a = l.current.findIndex(({ el: s })=>s === o);
        a !== -1 && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(i, {
            [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderStrategy"].Unmount] () {
                l.current.splice(a, 1);
            },
            [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderStrategy"].Hidden] () {
                l.current[a].state = "hidden";
            }
        }), R.microTask(()=>{
            var s;
            !M(l) && S.current && ((s = n.current) == null || s.call(n));
        }));
    }), y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((o)=>{
        let i = l.current.find(({ el: a })=>a === o);
        return i ? i.state !== "visible" && (i.state = "visible") : l.current.push({
            el: o,
            state: "visible"
        }), ()=>d(o, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderStrategy"].Unmount);
    }), C = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]), p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(Promise.resolve()), h = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        enter: [],
        leave: []
    }), g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((o, i, a)=>{
        C.current.splice(0), t && (t.chains.current[i] = t.chains.current[i].filter(([s])=>s !== o)), t == null || t.chains.current[i].push([
            o,
            new Promise((s)=>{
                C.current.push(s);
            })
        ]), t == null || t.chains.current[i].push([
            o,
            new Promise((s)=>{
                Promise.all(h.current[i].map(([r, f])=>f)).then(()=>s());
            })
        ]), i === "enter" ? p.current = p.current.then(()=>t == null ? void 0 : t.wait.current).then(()=>a(i)) : a(i);
    }), v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((o, i, a)=>{
        Promise.all(h.current[i].splice(0).map(([s, r])=>r)).then(()=>{
            var s;
            (s = C.current.shift()) == null || s();
        }).then(()=>a(i));
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            children: l,
            register: y,
            unregister: d,
            onStart: g,
            onStop: v,
            wait: p,
            chains: h
        }), [
        y,
        d,
        l,
        g,
        v,
        h,
        p
    ]);
}
let de = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], fe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderFeatures"].RenderStrategy;
function Fe(e, t) {
    var ee, te;
    let { transition: n = !0, beforeEnter: l, afterEnter: S, beforeLeave: R, afterLeave: d, enter: y, enterFrom: C, enterTo: p, entered: h, leave: g, leaveFrom: v, leaveTo: o, ...i } = e, [a, s] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), f = ue(e), U = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(...f ? [
        r,
        t,
        s
    ] : t === null ? [] : [
        t
    ]), H = (ee = i.unmount) == null || ee ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderStrategy"].Unmount : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderStrategy"].Hidden, { show: u, appear: z, initial: K } = He(), [m, j] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(u ? "visible" : "hidden"), Q = Ae(), { register: A, unregister: F } = Q;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>A(r), [
        A,
        r
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        if (H === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RenderStrategy"].Hidden && r.current) {
            if (u && m !== "visible") {
                j("visible");
                return;
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$match$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(m, {
                ["hidden"]: ()=>F(r),
                ["visible"]: ()=>A(r)
            });
        }
    }, [
        m,
        r,
        A,
        F,
        u,
        H
    ]);
    let G = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$server$2d$handoff$2d$complete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useServerHandoffComplete"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        if (f && G && m === "visible" && r.current === null) throw new Error("Did you forget to passthrough the `ref` to the actual DOM node?");
    }, [
        r,
        m,
        G,
        f
    ]);
    let ce = K && !z, Y = z && u && K, B = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), I = Te(()=>{
        B.current || (j("hidden"), F(r));
    }, Q), Z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((W)=>{
        B.current = !0;
        let L = W ? "enter" : "leave";
        I.onStart(r, L, (_)=>{
            _ === "enter" ? l == null || l() : _ === "leave" && (R == null || R());
        });
    }), $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])((W)=>{
        let L = W ? "enter" : "leave";
        B.current = !1, I.onStop(r, L, (_)=>{
            _ === "enter" ? S == null || S() : _ === "leave" && (d == null || d());
        }), L === "leave" && !M(I) && (j("hidden"), F(r));
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        f && n || (Z(u), $(u));
    }, [
        u,
        f,
        n
    ]);
    let pe = (()=>!(!n || !f || !G || ce))(), [, T] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])(pe, a, u, {
        start: Z,
        end: $
    }), Ce = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])({
        ref: U,
        className: ((te = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$class$2d$names$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["classNames"])(i.className, Y && y, Y && C, T.enter && y, T.enter && T.closed && C, T.enter && !T.closed && p, T.leave && g, T.leave && !T.closed && v, T.leave && T.closed && o, !T.transition && u && h)) == null ? void 0 : te.trim()) || void 0,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$transition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transitionDataAttributes"])(T)
    }), N = 0;
    m === "visible" && (N |= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Open), m === "hidden" && (N |= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Closed), u && m === "hidden" && (N |= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Opening), !u && m === "visible" && (N |= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Closing);
    let he = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(w.Provider, {
        value: I
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OpenClosedProvider"], {
        value: N
    }, he({
        ourProps: Ce,
        theirProps: i,
        defaultTag: de,
        features: fe,
        visible: m === "visible",
        name: "Transition.Child"
    })));
}
function Ie(e, t) {
    let { show: n, appear: l = !1, unmount: S = !0, ...R } = e, d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), y = ue(e), C = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$sync$2d$refs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncRefs"])(...y ? [
        d,
        t
    ] : t === null ? [] : [
        t
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$server$2d$handoff$2d$complete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useServerHandoffComplete"])();
    let p = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenClosed"])();
    if (n === void 0 && p !== null && (n = (p & __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Open) === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["State"].Open), n === void 0) throw new Error("A <Transition /> is used but it is missing a `show={true | false}` prop.");
    let [h, g] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(n ? "visible" : "hidden"), v = Te(()=>{
        n || g("hidden");
    }), [o, i] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!0), a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([
        n
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        o !== !1 && a.current[a.current.length - 1] !== n && (a.current.push(n), i(!1));
    }, [
        a,
        n
    ]);
    let s = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            show: n,
            appear: l,
            initial: o
        }), [
        n,
        l,
        o
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$iso$2d$morphic$2d$effect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoMorphicEffect"])(()=>{
        n ? g("visible") : !M(v) && d.current !== null && g("hidden");
    }, [
        n,
        v
    ]);
    let r = {
        unmount: S
    }, f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(()=>{
        var u;
        o && i(!1), (u = e.beforeEnter) == null || u.call(e);
    }), U = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$hooks$2f$use$2d$event$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEvent"])(()=>{
        var u;
        o && i(!1), (u = e.beforeLeave) == null || u.call(e);
    }), H = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRender"])();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(w.Provider, {
        value: v
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(V.Provider, {
        value: s
    }, H({
        ourProps: {
            ...r,
            as: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"],
            children: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(me, {
                ref: C,
                ...r,
                ...R,
                beforeEnter: f,
                beforeLeave: U
            })
        },
        theirProps: {},
        defaultTag: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"],
        features: fe,
        visible: h === "visible",
        name: "Transition"
    })));
}
function Le(e, t) {
    let n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(V) !== null, l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$internal$2f$open$2d$closed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenClosed"])() !== null;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, null, !n && l ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(X, {
        ref: t,
        ...e
    }) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(me, {
        ref: t,
        ...e
    }));
}
let X = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(Ie), me = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(Fe), Oe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$headlessui$2f$react$2f$dist$2f$utils$2f$render$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRefWithAs"])(Le), Ke = Object.assign(X, {
    Child: Oe,
    Root: X
});
;
}),
]);

//# sourceMappingURL=node_modules_%40headlessui_react_dist_8ba317c6._.js.map