(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__093b8241._.css",
  "static/chunks/node_modules_3603865d._.js",
  "static/chunks/src_1efd0b02._.js"
],
    source: "dynamic"
});
