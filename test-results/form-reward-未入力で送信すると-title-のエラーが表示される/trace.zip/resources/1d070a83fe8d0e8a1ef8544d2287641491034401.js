(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/organisms/Header/HeaderSkeleton.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_organisms_Header_HeaderSkeleton_tsx_cfad2a9e._.js",
  "static/chunks/src_components_organisms_Header_HeaderSkeleton_tsx_3c4806ce._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/organisms/Header/HeaderSkeleton.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);