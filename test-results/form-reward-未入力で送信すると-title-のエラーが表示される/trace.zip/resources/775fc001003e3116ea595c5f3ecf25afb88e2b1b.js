(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_organisms_Header_HeaderSkeleton_tsx_0b0d19ac._.js",
  "static/chunks/node_modules_@headlessui_react_dist_8ba317c6._.js",
  "static/chunks/node_modules_@floating-ui_react_dist_22386cb2._.js",
  "static/chunks/node_modules_next_c53cd0d8._.js",
  "static/chunks/node_modules_@mui_material_esm_ed8e54be._.js",
  "static/chunks/node_modules_@mui_system_esm_fa1f5294._.js",
  "static/chunks/node_modules_3de90b54._.js",
  "static/chunks/src_components_e07e4550._.js"
],
    source: "dynamic"
});
